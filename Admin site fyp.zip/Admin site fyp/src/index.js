import 'react-app-polyfill/stable'
import 'core-js'
import React from 'react'
import ReactDOM from 'react-dom'
import App from './App'
import reportWebVitals from './reportWebVitals'
import { Provider } from 'react-redux'
import store from './store'
import User from './views/dashboard/User'
import RepaymentsAdmin from './views/dashboard/RepaymentsAdmin'
//import LoanHistory from './views/dashboard/LoanHistory'
import ManageAccount from './views/dashboard/ManageAccount'
import Application from './views/dashboard/Application'
import ContactInfo from './views/dashboard/ContactInfo'
import IncomeDetails from './views/dashboard/IncomeDetails'
import BusinessDetails from './views/dashboard/BusinessDetails'
import EmployementDetail from './views/dashboard/EmployementDetail'
import DetailsOfReferences from './views/dashboard/DetailsOfReference'
import DocumentSubmission from './views/dashboard/DocumentSubmission'
import RepaymentStatement from './views/dashboard/RepaymentStatement'
import Hellow from './views/dashboard/Hellow'
import Dashboard from './views/dashboard/Dashboard'
import LoanHistory from './views/dashboard/LoanHistory'
import ViewDoc from './components/ViewDoc'
import UpdateUser from './components/UpdateUser'
ReactDOM.render(
  <Provider store={store}>
    <App />
  </Provider>,
  document.getElementById('root'),
)

// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
reportWebVitals()
