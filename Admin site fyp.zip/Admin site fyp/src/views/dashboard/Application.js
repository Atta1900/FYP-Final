import React from 'react'

import {
  CButton,
  CCard,
  CCardBody,
  CCol,
  CForm,
  CFormCheck,
  CFormInput,
  CFormLabel,
  CFormSelect,
  CRow,
} from '@coreui/react'

import { DocsExample } from 'src/components'

const Application = () => {
  return (
    <CRow>
      <CCol>
        <CCard className="mb-4">
          <CCardBody>
            <DocsExample href="forms/layout#gutters">
              <CForm className="row g-3">
                <h1>Personal Information</h1>
                <fieldset className="row mb-3">
                  <legend className="col-form-label col-sm-2 pt-0">Title</legend>
                  <CCol sm={10}>
                    <CFormCheck
                      type="radio"
                      name="gridRadios"
                      id="gridRadios1"
                      value="option1"
                      label="Mr"
                      defaultChecked
                    />
                    <CFormCheck
                      type="radio"
                      name="gridRadios"
                      id="gridRadios1"
                      value="option1"
                      label="Ms"
                    />
                    <CFormCheck
                      type="radio"
                      name="gridRadios"
                      id="gridRadios1"
                      value="option1"
                      label="Mrs"
                    />
                  </CCol>
                </fieldset>
                <CCol md={6}>
                  <CFormLabel htmlFor="inputText4">Full Name</CFormLabel>
                  <CFormInput type="Text" id="inputText4" />
                </CCol>
                <CCol md={6}>
                  <CFormLabel htmlFor="inputText4">Father Name</CFormLabel>
                  <CFormInput type="Text" id="inputText4" />
                </CCol>
                <CCol md={6}>
                  <CFormLabel htmlFor="inputText4">CNIC:</CFormLabel>
                  <CFormInput type="Text" id="inputText4" />
                </CCol>

                <CCol md={6}>
                  <CFormLabel htmlFor="inputText4">Old CNIC:</CFormLabel>
                  <CFormInput type="Text" id="inputText4" />
                </CCol>
                <CCol md={6}>
                  <CFormLabel htmlFor="inputText4">CNIC Issuance Date</CFormLabel>
                  <CFormInput type="date" id="inputText4" />
                </CCol>
                <CCol md={6}>
                  <CFormLabel htmlFor="inputText4">CNIC Expiry Date</CFormLabel>
                  <CFormInput type="date" id="inputText4" />
                </CCol>
                <CCol md={6}>
                  <CFormLabel htmlFor="inputText4">Passport Number</CFormLabel>
                  <CFormInput type="Text" id="inputText4" />
                </CCol>
                <CCol md={6}>
                  <CFormLabel htmlFor="inputText4">Date Of Birth</CFormLabel>
                  <CFormInput type="date" id="inputText4" />
                </CCol>
                <CCol md={6}>
                  <CFormLabel htmlFor="inputState">Marital Status</CFormLabel>
                  <CFormSelect id="inputState">
                    <option>Select</option>
                    <option>Married</option>
                    <option>Single</option>
                    <option>Divorced</option>
                    <option>Widowed</option>
                  </CFormSelect>
                </CCol>
                <CCol md={6}>
                  <CFormLabel htmlFor="inputText4">Dependants:</CFormLabel>
                  <CFormLabel htmlFor="inputText4">Number Of Children</CFormLabel>
                  <CFormInput type="Text" id="inputText4" />
                </CCol>
                <CCol md={6}>
                  <CFormLabel htmlFor="inputText4">Other Dependants</CFormLabel>
                  <CFormInput type="Text" id="inputText4" />
                </CCol>

                <CCol md={6}>
                  <CFormLabel htmlFor="inputState">Marital Status</CFormLabel>
                  <CFormSelect id="inputState">
                    <option>Select</option>
                    <option>Matric</option>
                    <option>Intermediate</option>
                    <option>A/O Level</option>
                    <option>Bechelor</option>
                    <option>Masters</option>
                    <option>M Phill</option>
                    <option>PHD</option>
                  </CFormSelect>
                </CCol>

                <fieldset className="row mb-3">
                  <legend className="col-form-label col-sm-2 pt-0">Gender</legend>

                  <CCol md={6}>
                    <CFormCheck
                      type="radio"
                      name="gridRadios"
                      id="gridRadios1"
                      value="option1"
                      label="Male"
                      defaultChecked
                    />

                    <CFormCheck
                      type="radio"
                      name="gridRadios"
                      id="gridRadios1"
                      value="option1"
                      label="Female"
                    />

                    <CFormCheck
                      type="radio"
                      name="gridRadios"
                      id="gridRadios1"
                      value="option1"
                      label="Other"
                    />
                  </CCol>
                </fieldset>

                <fieldset>
                  <CCol mb={3}>
                    <CButton type="submit">Prev Page</CButton>
                    <CButton type="submit">Next Page</CButton>
                  </CCol>
                </fieldset>


              </CForm>
            </DocsExample>
          </CCardBody>
        </CCard>
      </CCol>
    </CRow>
  )
}
export default Application
