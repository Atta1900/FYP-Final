import React from 'react'
import {
  CButton,
  CCard,
  CCardBody,
  CCol,
  CForm,
  CFormInput,
  CFormLabel,
  CFormSelect,
  CRow,
} from '@coreui/react'
import { DocsExample } from 'src/components'

const IncomeDetails = () => {
  return (
    <CRow>
      <CCol>
        <CCard className="mb-4">
          <CCardBody>
            <DocsExample href="forms/layout#gutters">
              <CForm className="row g-3">
                <h1>Income Details</h1>
                <CCol md={6}>
                  <CFormLabel htmlFor="inputText4">Monthly Gross Income</CFormLabel>
                  <CFormInput type="Text" id="inputText4" />
                </CCol>
                <CCol md={6}>
                  <CFormLabel htmlFor="inputText4">Monthly Net Income</CFormLabel>
                  <CFormInput type="Text" id="inputText4" />
                </CCol>

                <CCol md={6}>
                  <CFormLabel htmlFor="inputText4">Salaray Disbursement Day</CFormLabel>
                  <CFormInput type="date" id="inputText4" />
                </CCol>
                <CCol md={6}>
                  <CFormLabel htmlFor="inputText4">
                    Other Verifiable Income (if any) For SEP's Only
                  </CFormLabel>
                  <CFormInput type="Text" id="inputText4" />
                </CCol>
                <CCol md={6}>
                  <CFormLabel htmlFor="inputText4">Source Of Other Income</CFormLabel>
                  <CFormInput type="Text" id="inputText4" />
                </CCol>
                <CCol md={6}>
                  <CFormLabel htmlFor="inputText4">Average Monthly Income</CFormLabel>
                  <CFormInput type="Text" id="inputText4" />
                </CCol>

                <h1>Banking Details</h1>

                <CCol md={6}>
                  <CFormLabel htmlFor="inputText4">Bank Name</CFormLabel>
                  <CFormInput type="Text" id="inputText4" />
                </CCol>
                <CCol md={6}>
                  <CFormLabel htmlFor="inputText4">Account Number</CFormLabel>
                  <CFormInput type="Text" id="inputText4" />
                </CCol>

                <CCol md={6}>
                  <CFormLabel htmlFor="inputState">Resident Type</CFormLabel>
                  <CFormSelect id="inputState">
                    <option>Select</option>
                    <option>Current Account</option>
                    <option>Saving Account</option>
                    <option>Basic Banking Account</option>
                    <option>Foriegn Currency Account</option>
                    <option>Fixed Deposite Account</option>
                  </CFormSelect>
                </CCol>
                <CCol md={6}>
                  <CFormLabel htmlFor="inputText4">Bank Branch</CFormLabel>
                  <CFormInput type="text" id="inputText4" />
                </CCol>

                <h1>Desired Financing</h1>

                <CCol md={6}>
                  <CFormLabel htmlFor="inputState">Desired Repayment Tenure</CFormLabel>
                  <CFormSelect id="inputState">
                    <option>Select</option>
                    <option>12 Month</option>
                    <option>24 Month</option>
                    <option>36 Month</option>
                    <option>48 Month</option>
                    <option>Max Affordable Installment</option>
                  </CFormSelect>
                  <br></br>
                  <CFormInput type="text" id="inputText4" placeholder="If Other Please Specify" />
                </CCol>

                <CCol md={6}>
                  <CFormLabel htmlFor="inputState">Desired Repayment Tenure</CFormLabel>
                  <CFormSelect id="inputState">
                    <option>Select</option>
                    <option>Wedding</option>
                    <option>Vacation</option>
                    <option>Studies</option>
                    <option>Family Support</option>
                  </CFormSelect>
                  <br></br>
                  <CFormInput type="text" id="inputText4" placeholder=" If Other Please Specify" />
                </CCol>

                <CCol mb={3}>
                  <CFormLabel htmlFor="inputText4">Ammount Sought PKR</CFormLabel>
                  <CFormInput type="Text" id="inputText4" />
                </CCol>
                <CCol mb={3}>
                  <CButton type="submit">Prev Page</CButton>
                  <CButton type="submit">Next Page</CButton>
                </CCol>
              </CForm>
            </DocsExample>
          </CCardBody>
        </CCard>
      </CCol>
    </CRow>
  )
}
export default IncomeDetails
