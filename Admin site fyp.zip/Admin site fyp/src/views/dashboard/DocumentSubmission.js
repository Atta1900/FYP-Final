import React from 'react'

import {
    CButton,
    CCard,
    CCardBody,
    CCol,
    CForm,
    CFormInput,
    CFormLabel,
    CRow,
} from '@coreui/react'

import { DocsExample } from 'src/components'

const Application = () => {
    return (
        <CRow>
            <CCol>
                <CCard className="mb-4">
                    <CCardBody>
                        <DocsExample href="forms/layout#gutters">
                            <CForm className="row g-3">
                                <h1>Document Submission</h1>
                                <h3>Submit The Document in .pdf Format</h3>
                                <div className="mb-3">
                                    <CFormLabel htmlFor="formFile">Bank Statement Of Your Account Of Last 1 Year With The Signature Of Branch Manager</CFormLabel>
                                    <CFormInput type="file" id="formFile" />
                                </div>
                                <div className="mb-3">
                                    <CFormLabel htmlFor="formFile">Front And Back Clear Photo OF CNIC In .pdf Format</CFormLabel>
                                    <CFormInput type="file" id="formFile" />
                                </div>
                                <div className="mb-3">
                                    <CFormLabel htmlFor="formFile">Clear Picture Of Previously Paid K-ELectric Bill Of Your House</CFormLabel>
                                    <CFormInput type="file" id="formFile" />
                                </div>
                                <div className="mb-3">
                                    <CFormLabel htmlFor="formFile">Clear Picture Of Previously Paid Sui Southern Gas Company (SSGC) Bill Of Your House</CFormLabel>
                                    <CFormInput type="file" id="formFile" />
                                </div>
                                <div>
                                    <CCol mb={3}>
                                        <CButton type="submit">Go BacK To Application</CButton>
                                        <CButton type="submit">Submit The Document</CButton>
                                    </CCol>
                                </div>
                            </CForm>
                        </DocsExample>
                    </CCardBody>
                </CCard>
            </CCol>
        </CRow>
    )
}
export default Application
