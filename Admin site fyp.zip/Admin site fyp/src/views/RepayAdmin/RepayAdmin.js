import React, { useState, useEffect } from 'react'
import axios from 'axios'
import {
    CAvatar,
    CButton,
    CButtonGroup,
    CCard,
    CCardBody,
    CCardFooter,
    CCardHeader,
    CCol,
    CProgress,
    CRow,
    CTable,
    CTableBody,
    CTableDataCell,
    CTableHead,
    CTableHeaderCell,
    CTableRow,
} from '@coreui/react'
import { CChartLine } from '@coreui/react-chartjs'
import { getStyle, hexToRgba } from '@coreui/utils'
import CIcon from '@coreui/icons-react'
import {
    cibGoogle,
    cibFacebook,
    cibLinkedin,
    cibTwitter,
    cilCloudDownload,
    cilPeople,
    cilUser,
    cilUserFemale,
} from '@coreui/icons'

import avatar1 from 'src/assets/images/avatars/1.jpg'
import avatar2 from 'src/assets/images/avatars/2.jpg'
import avatar3 from 'src/assets/images/avatars/3.jpg'
import avatar4 from 'src/assets/images/avatars/4.jpg'

import avatar6 from 'src/assets/images/avatars/6.jpg'
import avatar7 from 'src/assets/images/avatars/7.jpg'
import avatar8 from 'src/assets/images/avatars/8.jpg'
import avatar9 from 'src/assets/images/avatars/9.jpg'

import { DocsExample } from 'src/components'

const RepayAdmin = () => {
    const [myData, setmyData] = useState([]);

    const allData = () => {

        axios({
            method: 'GET',
            url: "http://127.0.0.1:8000/api/ApplicationForm"
        })
            .then((response) => {
                var data = response.data;
                setmyData(data)
                console.log(data)

            }, (error) => {
                console.log(error);

            });
    }
    useEffect(() => {
        allData();
    }, myData.length)

    const updateStatus = async (id, status, item = null) => {
        var formdata = new FormData();
        formdata.append("alert", status);

        axios({
            method: 'PUT',
            url: `http://localhost:8000/api/UpdateAlert/${id}`,
            data: formdata,

        })
            .then((response) => {
                var data = response.data;
                console.log(data)
                allData();
                alert("Notification has been sent")

            }, (error) => {
                console.log(error);

            });
        if (status == "verification") {
            setVisible(true)
            setSingleData(item)

        }
    }

    return (
        <>
            <CRow>
                <CCol xs>
                    <CCard className="mb-4">
                        <h1>Pending Repayment Of The Month</h1>
                        <CCardBody>
                            <CTable align="middle" className="mb-0 border" hover responsive>
                                <CTableHead color="light">
                                    <CTableRow>
                                        <CTableHeaderCell className="text-center">
                                            <CIcon icon={cilPeople} />
                                        </CTableHeaderCell>
                                        <CTableHeaderCell className="text-center">Application No.</CTableHeaderCell>
                                        <CTableHeaderCell className="text-center">Name</CTableHeaderCell>
                                        <CTableHeaderCell className="text-center">Total Loan Amount</CTableHeaderCell>
                                        <CTableHeaderCell className="text-center">Total Paid Amount</CTableHeaderCell>
                                        <CTableHeaderCell className="text-center">Balance Amount</CTableHeaderCell>
                                        <CTableHeaderCell className="text-center">Installment Amount</CTableHeaderCell>
                                        <CTableHeaderCell className="text-center">Amount After Interest Rate</CTableHeaderCell>
                                        <CTableHeaderCell className="text-center">Date Of Installment</CTableHeaderCell>
                                        <CTableHeaderCell className="text-center">Action</CTableHeaderCell>
                                    </CTableRow>
                                </CTableHead>
                                <CTableBody>
                                    {myData.map((item, index) => (
                                        <CTableRow v-for="item in tableItems" key={index}>
                                            <CTableDataCell className="text-center">
                                                <CAvatar size="md" src={`http://127.0.0.1:8000${item.profilePicFile}`} />
                                            </CTableDataCell>
                                            <CTableDataCell className="text-center">
                                                <div>{item.applicationID}</div>
                                            </CTableDataCell>
                                            <CTableDataCell className="text-center">
                                                <div>{item.FirstName} {item.LastName}</div>
                                            </CTableDataCell>
                                            <CTableDataCell className="text-center">
                                                <div>{item.AmmountSoughtPKR}</div>
                                            </CTableDataCell>
                                            <CTableDataCell className="text-center">
                                                <div>{item.AmmountSoughtPKR - item.installementAmount}</div>
                                            </CTableDataCell>
                                            <CTableDataCell className="text-center">
                                                <div>{item.AccountNumber}</div>
                                            </CTableDataCell>
                                            <CTableDataCell className="text-center">
                                                <div>{item.installementAmount}</div>
                                            </CTableDataCell>
                                            <CTableDataCell className="text-center">
                                                <div>{item.AmmountSoughtPKR * 1.13}</div>
                                            </CTableDataCell>
                                            <CTableDataCell className="text-center">
                                                <div>{item.SalarayDisbursementDay}</div>
                                            </CTableDataCell>
                                            <CTableDataCell>
                                                <div>
                                                    <CButton class="btn btn-outline-primary" type='button' onClick={() => updateStatus(item.applicationID, "1")}>Alert</CButton>
                                                </div>
                                            </CTableDataCell>
                                        </CTableRow>
                                    ))}
                                </CTableBody>
                            </CTable>
                        </CCardBody>
                    </CCard>
                </CCol>
            </CRow>
        </>
    )
};
export default RepayAdmin