import React, { useState, useEffect } from 'react'
import axios from 'axios'
import {
    CButton,
    CCard,
    CCardBody,
    CCardFooter,
    CCardGroup,
    CCardHeader,
    CCardImage,
    CCardLink,
    CCardSubtitle,
    CCardText,
    CCardTitle,
    CListGroup,
    CListGroupItem,
    CNav,
    CNavItem,
    CNavLink,
    CCol,
    CRow,
} from '@coreui/react'
import { DocsExample } from 'src/components'

import ReactImg from 'src/assets/images/4.jpeg'



const Customers = () => {

    const [myData, setmyData] = useState([]);

    const allData = () => {

        axios({
            method: 'GET',
            url: "http://127.0.0.1:8000/api/ApplicationForm"
        })
            .then((response) => {
                var data = response.data;
                setmyData(data)
                console.log(data)

            }, (error) => {
                console.log(error);

            });
    }
    useEffect(() => {
        allData();
    }, myData.length)

    return (
        <>
            <DocsExample href="components/cards/#grid-cards">
                <CRow xs={{ cols: 1, gutter: 4 }} md={{ cols: 3 }}>
                    {myData.map((item, index) => (
                        <CCard key={index}>
                            <CCardImage orientation="top" src={`http://127.0.0.1:8000${item.profilePicFile}`} />                            <CCardBody>
                                <CCardTitle>{item.FirstName} {item.LastName}</CCardTitle>
                            </CCardBody>
                            <CListGroup>
                                <CListGroupItem>{item.applicationID}</CListGroupItem>
                                <CListGroupItem> {item.P_EmployementSince}</CListGroupItem>
                                <CListGroupItem>{item.DesiredRepTenure} Months</CListGroupItem>
                                <CListGroupItem>RS: {item.AmmountSoughtPKR}</CListGroupItem>
                            </CListGroup>
                            <CCardBody>
                                <CCardLink href=""> {item.installementAmount}</CCardLink>
                            </CCardBody>
                        </CCard>
                    ))};
                </CRow>
            </DocsExample>
        </>
    )
}

export default Customers;