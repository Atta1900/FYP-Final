import React, { useState, useEffect } from 'react'
import axios from 'axios'
import {
    CButton,
    CCard,
    CCardBody,
    CCol,
    CForm,
    CFormInput,
    CFormLabel,
    CFormSelect,
    CRow,
} from '@coreui/react'
import DocsExample from './DocsExample'

//const navform1 = useNavigate()

// const [isSuccess, setSuccess] = useState(false)
// const [isError, setError] = useState(false)
// const [errorMessage, setErrorMessage] = useState('')


// const handleSubmit = (e) => {
//     e.preventDefault();
//     if (Title === "" || FirstName === "" || MiddleName === "" || LastName === "") {
//         alert("All fields are required!");
//     } else {
//         navform1("/form2");
//     }
//};
function UpdateUser() {

    const [myData, setmyData] = useState([]);

    const allData = () => {
        axios({
            method: 'GET',
            url: "http://127.0.0.1:8000/api/ApplicationForm"
        })
            .then((response) => {
                var data = response.data;
                setmyData(data)
                console.log(data)
            }, (error) => {
                console.log(error);
            });
    }
    useEffect(() => {
        allData()
    }, myData.length)

    const [formData, setFormData] = useState({
        // Titles: '',
        FirstName: '',
        MiddleName: '',
        LastName: '',
        FatherName: '',
        CNIC: '',
        Old_Nic: '',
        CNIC_Is_Date: '',
        CNIC_Ex_Date: '',
        PassportNumber: '',
        DateOfBirth: '',
        MaritalStatus: '',
        Children: '',
        OtherDependants: '',
        Education: '',
        Gender: '',
        address: '',
        postalcode: '',
        city: '',
        mobileNumber: '',
        email: '',
        residentType: '',
        accomodationType: '',
        monthlyRent: '',
        installementAmount: '',
        permanentAddress: '',
        prepostalcode: '',
        cityPer: '',
        preresidentType: '',
        numberOfCar: '',
        Model: '',
        C_CompnayName: '',
        C_CompanyAddres: '',
        C_JobTitle: '',
        C_Department: '',
        C_EmployementSince: '',
        C_EmploymentNumber: '',
        C_Extension: '',
        C_OfficeEmail: '',
        C_EmployementType: '',
        P_CompnayName: '',
        P_CompanyAddres: '',
        P_JobTitle: '',
        P_Department: '',
        P_EmployementSince: '',
        P_EmployementSinceT: '',
        P_EmploymentNumber: '',
        P_Extension: '',
        P_OfficeEmail: '',
        P_EmployementType: '',
        MonthlyGrossIncome: '',
        MonthlyNetIncome: '',
        SalarayDisbursementDay: '',
        OtherVerIncome: '',
        SourceOfOtherIncome: '',
        AverageMonthlyIncome: '',
        BankName: '',
        AccountNumber: '',
        AccountType: '',
        Branch: '',
        DesiredRepTenure: '',
        LoanReqFor: '',
        // s_LoanReqFor: '',
        AmmountSoughtPKR: '',
        // IncomeAmountPreMonth: '',
        numberOfBusiness: '',
        businessTitle: '',
        businessAddress: '',
        businessType: '',
        industryType: '',
        ntnNumber: '',
        establishedSince: '',
        registerWith: '',
        businessTelephoneNumber: '',
        businessEmail: '',
        companyName: '',
        typeOfBusiness: '',
        s_specify_TypeOFBusiness: '',
        professionalQualifications: '',
        // s_specify_professionalQualifications: '',
        R_FullName: '',
        R_CINC: '',
        R_PossportNumber: '',
        R_Address: '',
        R_TelephoneNumOffice: '',
        R_TelephoneNumResidence: '',
        R_Email: '',
        R_CellNumber: '',
        R_Relationship: '',
        R2_FullName: '',
        R2_CINC: '',
        R2_PossportNumber: '',
        R2_Address: '',
        R2_TelephoneNumOffice: '',
        R2_TelephoneNumResidence: '',
        R2_Email: '',
        R2_CellNumber: '',
        R2_Relationship: '',
        bankStatementFile: null,
        nicPicFile: null,
        keBillFile: null,
        gasBillFile: null,
        profilePicFile: null,

    });

    return (
        <>
            {myData.map((item, index) => (

                <div>

                    <CRow className='justify-content-center'>
                        <CCol md={5}>
                            <CCard className="mb-6">
                                <CCardBody>
                                    <DocsExample href="forms/layout#gutters">
                                        <CForm className="row g-3">
                                            <h1 className='text-justify-center'>Personal Information</h1>
                                            <fieldset></fieldset>
                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputText5">First Name</CFormLabel>
                                                <br></br>
                                                <CFormLabel htmlFor="inputText4">{item.FirstName}</CFormLabel>
                                                <CFormInput type="Text" id="inputText4" required />
                                            </CCol>
                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputText5">Middle Name</CFormLabel>
                                                <CFormInput value={formData.MiddleName} type="Text" id="inputText4" onChange={(e) => setFormData({ ...formData, MiddleName: e.target.value })} required />
                                            </CCol>
                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputText4">Last Name</CFormLabel>
                                                <CFormInput value={formData.LastName} onChange={(e) => setFormData({ ...formData, LastName: e.target.value })} type="Text" id="inputText4" required />
                                            </CCol>
                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputText4">Father Name</CFormLabel>
                                                <CFormInput type="Text" id="inputText4" value={formData.FatherName} onChange={(e) => setFormData({ ...formData, FatherName: e.target.value })} required />
                                            </CCol>
                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputText4">CNIC:</CFormLabel>
                                                <CFormInput type="Number" id="inputText4" value={formData.CNIC} onChange={(e) => setFormData({ ...formData, CNIC: e.target.value })} required />
                                            </CCol>

                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputText4">Old CNIC:</CFormLabel>
                                                <CFormInput type="Number" placeholder="if any" id="inputText4" value={formData.Old_Nic} onChange={(e) => setFormData({ ...formData, Old_Nic: e.target.value })} required />
                                            </CCol>
                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputText4">CNIC Issuance Date</CFormLabel>
                                                <CFormInput type="date" id="inputText4" value={formData.CNIC_Is_Date} onChange={(e) => setFormData({ ...formData, CNIC_Is_Date: e.target.value })} required />
                                            </CCol>
                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputText4">CNIC Expiry Date</CFormLabel>
                                                <CFormInput type="date" id="inputText4" value={formData.CNIC_Ex_Date} onChange={(e) => setFormData({ ...formData, CNIC_Ex_Date: e.target.value })} required />
                                            </CCol>
                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputText4">Passport Number</CFormLabel>
                                                <CFormInput type="Text" id="inputText4" value={formData.PassportNumber} onChange={(e) => setFormData({ ...formData, PassportNumber: e.target.value })} required />
                                            </CCol>
                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputText4">Date Of Birth</CFormLabel>
                                                <CFormInput type="date" id="inputText4" value={formData.DateOfBirth} onChange={(e) => setFormData({ ...formData, DateOfBirth: e.target.value })} required />
                                            </CCol>
                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputState">Marital Status</CFormLabel>
                                                <CFormSelect id="inputState" value={formData.MaritalStatus} onChange={(e) => setFormData({ ...formData, MaritalStatus: e.target.value })} required >
                                                    <option>Select</option>
                                                    <option>Married</option>
                                                    <option>Single</option>
                                                    <option>Divorced</option>
                                                    <option>Widowed</option>
                                                </CFormSelect>
                                            </CCol>
                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputText4">Dependants</CFormLabel>
                                                <CFormLabel htmlFor="inputText4">: Number Of Children</CFormLabel>
                                                <CFormInput type="Number" id="inputText4" value={formData.Children} onChange={(e) => setFormData({ ...formData, Children: e.target.value })} required />
                                            </CCol>
                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputText4">Other Dependants</CFormLabel>
                                                <CFormInput type="Number" id="inputText4" placeholder='e.g Father/Mother' value={formData.OtherDependants} onChange={(e) => setFormData({ ...formData, OtherDependants: e.target.value })} required />
                                            </CCol>

                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputState">Education</CFormLabel>
                                                <CFormSelect id="inputState" value={formData.Education} onChange={(e) => setFormData({ ...formData, Education: e.target.value })} required>
                                                    <option>Select</option>
                                                    <option>Matric</option>
                                                    <option>Intermediate</option>
                                                    <option>A/O Level</option>
                                                    <option>Bechelor</option>
                                                    <option>Masters</option>
                                                    <option>M Phill</option>
                                                    <option>PHD</option>
                                                </CFormSelect>
                                            </CCol>
                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputState">Gender</CFormLabel>
                                                <CFormSelect id="inputState" value={formData.Gender} onChange={(e) => setFormData({ ...formData, Gender: e.target.value })} required>
                                                    <option>Select</option>
                                                    <option>Male</option>
                                                    <option>Female</option>
                                                </CFormSelect>
                                            </CCol>
                                        </CForm>
                                    </DocsExample>
                                </CCardBody>
                            </CCard>
                        </CCol>
                    </CRow>
                    <CRow className='justify-content-center'>
                        <CCol md={5}>
                            <CCard className="mb-6">
                                <CCardBody>
                                    <DocsExample href="forms/layout#gutters">
                                        <CForm className="row g-3">
                                            <h1>Contact Info</h1>
                                            <CCol xs={12}>
                                                <CFormLabel htmlFor="inputText4">Address</CFormLabel>
                                                <CFormInput id="inputAddress" type='Text' value={formData.address} onChange={(e) => setFormData({ ...formData, address: e.target.value })} required />
                                            </CCol>
                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputText4">Postal Code</CFormLabel>
                                                <CFormInput type="Number" id="inputText4" value={formData.postalcode} onChange={(e) => setFormData({ ...formData, postalcode: e.target.value })} required />
                                            </CCol>
                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputText4">City</CFormLabel>
                                                <CFormInput type="Text" id="inputText4" value={formData.city} onChange={(e) => setFormData({ ...formData, city: e.target.value })} required />
                                            </CCol>

                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputText4">Mobile Number</CFormLabel>
                                                <CFormInput type="Number" id="inputText4" value={formData.mobileNumber} onChange={(e) => setFormData({ ...formData, mobileNumber: e.target.value })} required />
                                            </CCol>
                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputText4">Email</CFormLabel>
                                                <CFormInput type="Email" id="inputText4" value={formData.email} onChange={(e) => setFormData({ ...formData, email: e.target.value })} required />
                                            </CCol>
                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputState">Resident Type</CFormLabel>
                                                <CFormSelect id="inputState" value={formData.residentType} onChange={(e) => setFormData({ ...formData, residentType: e.target.value })} required>
                                                    <option>Select</option>
                                                    <option>Owned</option>
                                                    <option>Rented</option>
                                                    <option>Company</option>
                                                    <option>Parents</option>
                                                    <option>Financed/Leased</option>
                                                </CFormSelect>
                                            </CCol>
                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputState">Accomodation Type</CFormLabel>
                                                <CFormSelect id="inputState" value={formData.accomodationType} onChange={(e) => setFormData({ ...formData, accomodationType: e.target.value })} required>
                                                    <option>Select</option>
                                                    <option>House</option>
                                                    <option>Appartment</option>
                                                    <option>Portion</option>
                                                    <option>Room</option>
                                                </CFormSelect>
                                            </CCol>

                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputText4">Monthly Rent (If Rented)</CFormLabel>
                                                <CFormInput type="Number" id="inputText4" value={formData.monthlyRent} onChange={(e) => setFormData({ ...formData, monthlyRent: e.target.value })} required />
                                            </CCol>
                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputText4">Installment Amount (If Motgage)</CFormLabel>
                                                <CFormInput type="Number" id="inputText4" value={formData.installementAmount} onChange={(e) => setFormData({ ...formData, installementAmount: e.target.value })} required />
                                            </CCol>

                                            <CCol xs={12}>
                                                <CFormLabel htmlFor="inputText4">Permanent Address</CFormLabel>
                                                <CFormInput id="inputAddress" type='Text' value={formData.permanentAddress} onChange={(e) => setFormData({ ...formData, permanentAddress: e.target.value })} required />
                                            </CCol>
                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputText4">Postal Code (Permanent)</CFormLabel>
                                                <CFormInput type="Number" id="inputText4" value={formData.prepostalcode} onChange={(e) => setFormData({ ...formData, prepostalcode: e.target.value })} required />
                                            </CCol>
                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputText4">City (Permanent)</CFormLabel>
                                                <CFormInput type="Text" id="inputText4" value={formData.cityPer} onChange={(e) => setFormData({ ...formData, cityPer: e.target.value })} required />
                                            </CCol>

                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputState">Resident Type (Permanent)</CFormLabel>
                                                <CFormSelect id="inputState" value={formData.preresidentType} onChange={(e) => setFormData({ ...formData, preresidentType: e.target.value })} required>
                                                    <option>Select</option>
                                                    <option>Owned</option>
                                                    <option>Rented</option>
                                                    <option>Company</option>
                                                    <option>Parents</option>
                                                    <option>Financed/Leased</option>
                                                </CFormSelect>
                                            </CCol>

                                            <CCol mb={3}>
                                                <CFormLabel htmlFor="inputText4">Number Of Cars</CFormLabel>
                                                <CFormInput type="Number" id="inputText4" value={formData.numberOfCar} onChange={(e) => setFormData({ ...formData, numberOfCar: e.target.value })} />
                                            </CCol>

                                            <CCol md={3}>
                                                <CFormLabel htmlFor="inputText4">Make & Model</CFormLabel>
                                                <CFormInput type="Text" id="inputText4" value={formData.Model} onChange={(e) => setFormData({ ...formData, Model: e.target.value })} />
                                            </CCol>

                                        </CForm>
                                    </DocsExample>
                                </CCardBody>
                            </CCard>
                        </CCol>
                    </CRow>
                    <CRow className='justify-content-center'>
                        <CCol md={5}>
                            <CCard className="mb-6">
                                <CCardBody>
                                    <DocsExample href="forms/layout#gutters">
                                        <CForm className="row g-3">
                                            <h1>Employement Details </h1>
                                            <h6>For Salaried Individual Only Otherwise Filled with (-) & Go To Next Page</h6>
                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputText4">Company Name</CFormLabel>
                                                <CFormInput value={formData.C_CompnayName} type="Text" id="inputText4" onChange={(e) => setFormData({ ...formData, C_CompnayName: e.target.value })} required />
                                            </CCol>
                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputText4">Company Address</CFormLabel>
                                                <CFormInput value={formData.C_CompanyAddres} type="Text" id="inputText4" onChange={(e) => setFormData({ ...formData, C_CompanyAddres: e.target.value })} required />
                                            </CCol>
                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputText4">Job Title</CFormLabel>
                                                <CFormInput value={formData.C_JobTitle} type="Text" id="inputText4" onChange={(e) => setFormData({ ...formData, C_JobTitle: e.target.value })} required />
                                            </CCol>
                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputText4">Department</CFormLabel>
                                                <CFormInput value={formData.C_Department} type="Text" id="inputText4" onChange={(e) => setFormData({ ...formData, C_Department: e.target.value })} required />
                                            </CCol>
                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputText4">Employement Since</CFormLabel>
                                                <CFormInput type="date" value={formData.C_EmployementSince} id="inputText4" onChange={(e) => setFormData({ ...formData, C_EmployementSince: e.target.value })} required />
                                            </CCol>
                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputText4">Employement Number</CFormLabel>
                                                <CFormInput value={formData.C_EmploymentNumber} type="Text" id="inputText4" onChange={(e) => setFormData({ ...formData, C_EmploymentNumber: e.target.value })} required />
                                            </CCol>
                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputText4">Extension</CFormLabel>
                                                <CFormInput value={formData.C_Extension} type="Text" id="inputText4" onChange={(e) => setFormData({ ...formData, C_Extension: e.target.value })} required />
                                            </CCol>
                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputText4">Office Email</CFormLabel>
                                                <CFormInput value={formData.C_OfficeEmail} type="Email" id="inputText4" onChange={(e) => setFormData({ ...formData, C_OfficeEmail: e.target.value })} required />
                                            </CCol>
                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputState">Employement Type</CFormLabel>
                                                <CFormSelect id="inputState" value={formData.C_EmployementType} onChange={(e) => setFormData({ ...formData, C_EmployementType: e.target.value })} required>
                                                    <option>Select</option>
                                                    <option>Permanent</option>
                                                    <option>Contractual</option>
                                                </CFormSelect>
                                            </CCol>

                                            <h1>Previous Employement Details</h1>
                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputText4">Company Name</CFormLabel>
                                                <CFormInput value={formData.P_CompnayName} type="Text" id="inputText4" onChange={(e) => setFormData({ ...formData, P_CompnayName: e.target.value })} required />
                                            </CCol>
                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputText4">Company Address</CFormLabel>
                                                <CFormInput value={formData.P_CompanyAddres} type="Text" id="inputText4" onChange={(e) => setFormData({ ...formData, P_CompanyAddres: e.target.value })} required />
                                            </CCol>
                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputText4">Job Title</CFormLabel>
                                                <CFormInput value={formData.P_JobTitle} type="Text" id="inputText4" onChange={(e) => setFormData({ ...formData, P_JobTitle: e.target.value })} required />
                                            </CCol>
                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputText4">Department</CFormLabel>
                                                <CFormInput value={formData.P_Department} type="Text" id="inputText4" onChange={(e) => setFormData({ ...formData, P_Department: e.target.value })} required />
                                            </CCol>
                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputText4">Employement Period</CFormLabel>
                                                <br></br>
                                                <CFormLabel htmlFor="inputText4">From</CFormLabel>
                                                <CFormInput type="date" id="inputText4" value={formData.P_EmployementSince} onChange={(e) => setFormData({ ...formData, P_EmployementSince: e.target.value })} required />
                                            </CCol>
                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputText4">Employement Period</CFormLabel>
                                                <br></br>
                                                <CFormLabel htmlFor="inputText4">To</CFormLabel>
                                                <CFormInput type="date" value={formData.P_EmployementSinceT} id="inputText4" onChange={(e) => setFormData({ ...formData, P_EmployementSinceT: e.target.value })} required />
                                            </CCol>
                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputText4">Employement Number</CFormLabel>
                                                <CFormInput value={formData.P_EmploymentNumber} type="Text" id="inputText4" onChange={(e) => setFormData({ ...formData, P_EmploymentNumber: e.target.value })} required />
                                            </CCol>
                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputText4">Extension</CFormLabel>
                                                <CFormInput value={formData.P_Extension} type="Text" id="inputText4" onChange={(e) => setFormData({ ...formData, P_Extension: e.target.value })} required />
                                            </CCol>
                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputText4">Office Email</CFormLabel>
                                                <CFormInput value={formData.P_OfficeEmail} type="Email" id="inputText4" onChange={(e) => setFormData({ ...formData, P_OfficeEmail: e.target.value })} required />
                                            </CCol>
                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputState">Employement Type</CFormLabel>
                                                <CFormSelect id="inputState" value={formData.P_EmployementType} onChange={(e) => setFormData({ ...formData, P_EmployementType: e.target.value })} required>
                                                    <option>Select</option>
                                                    <option>Permanent</option>
                                                    <option>Contractual</option>
                                                </CFormSelect>
                                            </CCol>
                                        </CForm>
                                    </DocsExample>
                                </CCardBody>
                            </CCard>
                        </CCol>
                    </CRow>
                    <CRow className='justify-content-center'>
                        <CCol md={5}>
                            <CCard className="mb-6">
                                <CCardBody>
                                    <DocsExample>
                                        <CForm className="row g-3">
                                            <h1>Business Details </h1>
                                            <h4>*If Your Income Is From Business*</h4>
                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputText4">Number Of Business</CFormLabel>
                                                <CFormInput value={formData.numberOfBusiness} type="Number" id="inputText4" onChange={(e) => setFormData({ ...formData, numberOfBusiness: e.target.value })} required />
                                            </CCol>
                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputText4">Business Title</CFormLabel>
                                                <CFormInput value={formData.businessTitle} type="Text" id="inputText4" onChange={(e) => setFormData({ ...formData, businessTitle: e.target.value })} required />
                                            </CCol>
                                            <CCol xs={12}>
                                                <CFormLabel htmlFor="inputText4">Business Address</CFormLabel>
                                                <CFormInput id="inputAddress" type='Text' value={formData.businessAddress} onChange={(e) => setFormData({ ...formData, businessAddress: e.target.value })} required />
                                            </CCol>
                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputText4">Business Type</CFormLabel>
                                                <CFormInput value={formData.businessType} type="Text" id="inputText4" onChange={(e) => setFormData({ ...formData, businessType: e.target.value })} required />
                                            </CCol>
                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputText4">Industry Type</CFormLabel>
                                                <CFormInput value={formData.industryType} type="Text" id="inputText4" onChange={(e) => setFormData({ ...formData, industryType: e.target.value })} required />
                                            </CCol>
                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputText4">Business's NTN Number</CFormLabel>
                                                <CFormInput value={formData.ntnNumber} type="Text" id="inputText4" onChange={(e) => setFormData({ ...formData, ntnNumber: e.target.value })} required />
                                            </CCol>
                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputText4">Established Since</CFormLabel>
                                                <CFormInput type="date" id="inputText4" value={formData.establishedSince} onChange={(e) => setFormData({ ...formData, establishedSince: e.target.value })} required />
                                            </CCol>
                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputText4">Register With</CFormLabel>
                                                <CFormInput value={formData.registerWith} type="Text" id="inputText4" onChange={(e) => setFormData({ ...formData, registerWith: e.target.value })} required />
                                            </CCol>
                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputText4">Business Telephone Number</CFormLabel>
                                                <CFormInput value={formData.businessTelephoneNumber} type="Number" id="inputText4" onChange={(e) => setFormData({ ...formData, businessTelephoneNumber: e.target.value })} required />
                                            </CCol>
                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputText4">Business Email</CFormLabel>
                                                <br></br>
                                                <br></br>

                                                <CFormInput value={formData.businessEmail} type="Email" id="inputText4" onChange={(e) => setFormData({ ...formData, businessEmail: e.target.value })} required />
                                            </CCol>
                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputText4">Self Employed Professionals (SEP):</CFormLabel>
                                                <br></br>
                                                <CFormLabel htmlFor="inputText4">Name Of Company</CFormLabel>
                                                <CFormInput value={formData.companyName} type="Text" id="inputText4" onChange={(e) => setFormData({ ...formData, companyName: e.target.value })} required />
                                            </CCol>

                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputState">Type Of Business</CFormLabel>
                                                <CFormSelect id="inputState" value={formData.typeOfBusiness} onChange={(e) => setFormData({ ...formData, typeOfBusiness: e.target.value })} required>
                                                    <option>Select</option>
                                                    <option>Sole Proprietorship</option>
                                                    <option>Patnership</option>
                                                    <option>Limited Liability Companies (LLC)</option>
                                                    <option>Corporations</option>
                                                </CFormSelect>
                                            </CCol>

                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputState">Professional Qualifications</CFormLabel>
                                                <CFormSelect id="inputState" value={formData.professionalQualifications} onChange={(e) => setFormData({ ...formData, professionalQualifications: e.target.value })} required>
                                                    <option>Select</option>
                                                    <option>Chartered Accountant</option>
                                                    <option>Doctor</option>
                                                    <option>Engineer</option>
                                                    <option>Architect</option>
                                                    <option>Other</option>
                                                </CFormSelect>
                                                <br></br>
                                                <CFormInput type="Text" id="inputText4" placeholder="Please Specify OR Enter Again Same Profession " value={formData.s_specify_professionalQualifications} onChange={(e) => setFormData({ ...formData, s_specify_professionalQualifications: e.target.value })} required />
                                            </CCol>
                                        </CForm>
                                    </DocsExample>
                                </CCardBody>
                            </CCard>
                        </CCol>
                    </CRow>
                    <CRow className='justify-content-center'>
                        <CCol md={5}>
                            <CCard className="mb-6">
                                <CCardBody>
                                    <DocsExample href="forms/layout#gutters">
                                        <CForm className="row g-3">
                                            <h1>Income Details</h1>
                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputText4">Monthly Gross Income</CFormLabel>
                                                <CFormInput value={formData.MonthlyGrossIncome} type="Number" id="inputText4" onChange={(e) => setFormData({ ...formData, MonthlyGrossIncome: e.target.value })} required />
                                            </CCol>
                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputText4">Monthly Net Income</CFormLabel>
                                                <CFormInput value={formData.MonthlyNetIncome} type="Number" id="inputText4" onChange={(e) => setFormData({ ...formData, MonthlyNetIncome: e.target.value })} required />
                                            </CCol>

                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputText4">Salaray Disbursement Day</CFormLabel>
                                                <CFormInput type="date" id="inputText4" value={formData.SalarayDisbursementDay} onChange={(e) => setFormData({ ...formData, SalarayDisbursementDay: e.target.value })} required />
                                            </CCol>
                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputText4">
                                                    Other Verifiable Income (if any) For SEP's Only
                                                </CFormLabel>
                                                <CFormInput value={formData.OtherVerIncome} type="Number" id="inputText4" onChange={(e) => setFormData({ ...formData, OtherVerIncome: e.target.value })} required />
                                            </CCol>
                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputText4">Source Of Other Income</CFormLabel>
                                                <CFormInput value={formData.SourceOfOtherIncome} type="Text" id="inputText4" onChange={(e) => setFormData({ ...formData, SourceOfOtherIncome: e.target.value })} required />
                                            </CCol>
                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputText4">Average Monthly Income</CFormLabel>
                                                <CFormInput value={formData.AverageMonthlyIncome} type="Number" id="inputText4" onChange={(e) => setFormData({ ...formData, AverageMonthlyIncome: e.target.value })} required />
                                            </CCol>

                                            <h1>Banking Details</h1>

                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputText4">Bank Name</CFormLabel>
                                                <CFormInput value={formData.BankName} type="Text" id="inputText4" onChange={(e) => setFormData({ ...formData, BankName: e.target.value })} required />
                                            </CCol>
                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputText4">Account Number</CFormLabel>
                                                <CFormInput value={formData.AccountNumber} type="Text" id="inputText4" onChange={(e) => setFormData({ ...formData, AccountNumber: e.target.value })} required />
                                            </CCol>

                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputState">Account Type</CFormLabel>
                                                <CFormSelect id="inputState" value={formData.AccountType} onChange={(e) => setFormData({ ...formData, AccountType: e.target.value })} required>
                                                    <option>Select</option>
                                                    <option>Current Account</option>
                                                    <option>Saving Account</option>                   </CFormSelect>
                                            </CCol>
                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputText4">Bank Branch</CFormLabel>
                                                <CFormInput value={formData.Branch} type="Text" id="inputText4" onChange={(e) => setFormData({ ...formData, Branch: e.target.value })} required />
                                            </CCol>

                                            <h1>Desired Financing</h1>

                                            <CCol mb={3}>
                                                <CFormLabel htmlFor="inputText4">Ammount Sought PKR</CFormLabel>
                                                <CFormInput value={formData.AmmountSoughtPKR} onChange={(e) => setFormData({ ...formData, AmmountSoughtPKR: e.target.value })} type="Number" id="inputText4" required />
                                            </CCol>

                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputState">Desired Repayment Tenure</CFormLabel>
                                                <CFormInput id="inputState" type='Number' value={formData.DesiredRepTenure} onChange={(e) => setFormData({ ...formData, DesiredRepTenure: e.target.value })} placeholder="12,24,36,48,60" required />
                                            </CCol>

                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputState">Loan Required For</CFormLabel>
                                                <CFormSelect id="inputState" value={formData.LoanReqFor} onChange={(e) => setFormData({ ...formData, LoanReqFor: e.target.value })} required >
                                                    <option>Select</option>
                                                    <option>Wedding</option>
                                                    <option>Vacation</option>
                                                    <option>Studies</option>
                                                    <option>Family Support</option>
                                                </CFormSelect>
                                            </CCol>
                                        </CForm>
                                    </DocsExample>
                                </CCardBody>
                            </CCard>
                        </CCol>
                    </CRow>
                    <CRow className='justify-content-center'>
                        <CCol md={5}>
                            <CCard className="mb-6">
                                <CCardBody>
                                    <DocsExample href="forms/layout#gutters">
                                        <CForm className="row g-3">
                                            <h1>Details Of References</h1>
                                            <h3>Reference 01</h3>
                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputText4">Full Name</CFormLabel>
                                                <CFormInput value={formData.R_FullName} onChange={(e) => setFormData({ ...formData, R_FullName: e.target.value })} type="Text" id="inputText4" required />
                                            </CCol>
                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputText4">CNIC</CFormLabel>
                                                <CFormInput value={formData.R_CINC} onChange={(e) => setFormData({ ...formData, R_CINC: e.target.value })} type="Number" id="inputText4" required />
                                            </CCol>
                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputText4">Passport Number</CFormLabel>
                                                <CFormInput value={formData.R_PossportNumber} onChange={(e) => setFormData({ ...formData, R_PossportNumber: e.target.value })} type="Text" id="inputText4" required />
                                            </CCol>
                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputText4">Address</CFormLabel>
                                                <CFormInput value={formData.R_Address} onChange={(e) => setFormData({ ...formData, R_Address: e.target.value })} type="Text" id="inputText4" required />
                                            </CCol>
                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputText4">Telephone Number Office</CFormLabel>
                                                <CFormInput value={formData.R_TelephoneNumOffice} onChange={(e) => setFormData({ ...formData, R_TelephoneNumOffice: e.target.value })} type="Number" id="inputText4" required />
                                            </CCol>
                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputText4">Telephone Number Residence</CFormLabel>
                                                <CFormInput value={formData.R_TelephoneNumResidence} onChange={(e) => setFormData({ ...formData, R_TelephoneNumResidence: e.target.value })} type="Number" id="inputText4" required />
                                            </CCol>

                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputText4">Email</CFormLabel>
                                                <CFormInput value={formData.R_Email} onChange={(e) => setFormData({ ...formData, R_Email: e.target.value })} type="Email" id="inputText4" required />
                                            </CCol>

                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputText4">Cell Number</CFormLabel>
                                                <CFormInput value={formData.R_CellNumber} onChange={(e) => setFormData({ ...formData, R_CellNumber: e.target.value })} type="Number" id="inputText4" required />
                                            </CCol>
                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputText4">Relationship</CFormLabel>
                                                <CFormInput value={formData.R_Relationship} onChange={(e) => setFormData({ ...formData, R_Relationship: e.target.value })} type="Text" id="inputText4" required />
                                            </CCol>

                                            <h3>Reference 02</h3>
                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputText4">Full Name</CFormLabel>
                                                <CFormInput value={formData.R2_FullName} onChange={(e) => setFormData({ ...formData, R2_FullName: e.target.value })} type="Text" id="inputText4" required />
                                            </CCol>
                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputText4">CNIC</CFormLabel>
                                                <CFormInput value={formData.R2_CINC} onChange={(e) => setFormData({ ...formData, R2_CINC: e.target.value })} type="Number" id="inputText4" required />
                                            </CCol>
                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputText4">Passport Number</CFormLabel>
                                                <CFormInput value={formData.R2_PossportNumber} onChange={(e) => setFormData({ ...formData, R2_PossportNumber: e.target.value })} type="Text" id="inputText4" required />
                                            </CCol>
                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputText4">Address</CFormLabel>
                                                <CFormInput value={formData.R2_Address} onChange={(e) => setFormData({ ...formData, R2_Address: e.target.value })} type="Text" id="inputText4" required />
                                            </CCol>
                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputText4">Telephone Number Office</CFormLabel>
                                                <CFormInput value={formData.R2_TelephoneNumOffice} onChange={(e) => setFormData({ ...formData, R2_TelephoneNumOffice: e.target.value })} type="Number" id="inputText4" required />
                                            </CCol>
                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputText4">Telephone Number Residencec</CFormLabel>
                                                <CFormInput value={formData.R2_TelephoneNumResidence} onChange={(e) => setFormData({ ...formData, R2_TelephoneNumResidence: e.target.value })} type="Number" id="inputText4" required />
                                            </CCol>

                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputText4">Email</CFormLabel>
                                                <CFormInput value={formData.R2_Email} onChange={(e) => setFormData({ ...formData, R2_Email: e.target.value })} type="Email" id="inputText4" required />
                                            </CCol>

                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputText4">Cell Number</CFormLabel>
                                                <CFormInput value={formData.R2_CellNumber} onChange={(e) => setFormData({ ...formData, R2_CellNumber: e.target.value })} type="Number" id="inputText4" required />
                                            </CCol>
                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputText4">Relationship</CFormLabel>
                                                <CFormInput value={formData.R2_Relationship} onChange={(e) => setFormData({ ...formData, R2_Relationship: e.target.value })} type="Text" id="inputText4" required />
                                            </CCol>
                                        </CForm>
                                    </DocsExample>
                                </CCardBody>
                            </CCard>

                        </CCol>
                    </CRow>
                </div>

            ))}

        </>
    );
}
export default UpdateUser