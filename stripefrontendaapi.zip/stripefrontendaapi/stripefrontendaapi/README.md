# Getting Started with Create React App

This project was bootstrapped with [Create React App](https://github.com/facebook/create-react-app).

## Stripe React frontend 
this is a simple project for  youtube tutorial that show how to implement stripe payment in react using django rest framework as our backend api server

with implement the hosted checkout payment at first and later migrated to   the custom payment flow checkout, you can check the tutorial out on my youtube channel. 







