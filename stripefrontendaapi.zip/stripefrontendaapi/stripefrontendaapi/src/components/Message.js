import React from 'react'

const Message = ({message}) => {
    return (
        <div className='container'>
            
            <p>order completed . thanks for purschase our product</p>
            
        </div>
    )
}

export default Message
