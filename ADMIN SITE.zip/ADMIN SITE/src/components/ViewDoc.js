import axios from 'axios';
import React, { useState, useEffect } from 'react'
import { Document, Page } from 'react-pdf';
import { useLocation } from 'react-router-dom';

const ViewDoc = (props) => {
    const location = useLocation();
    const [myData, setmyData] = useState([]);

    const allData = () => {
        alert("hello")
        axios({
            method: 'GET',
            url: "http://127.0.0.1:8000/api/ApplicationForm"
        })
            .then((response) => {
                var data = response.data;
                var singleUser = data.filter((e) => {
                    return localStorage.getItem('id') == e.applicationID
                })
                setmyData(singleUser)
                console.log(data)
                console.log(singleUser)

            }, (error) => {
                console.log(error);


            });
    }
    useEffect(() => {
        allData()
    }, [], myData.length)


    return (
        <>
            <div>
                <h1>Test</h1>
                {myData.map((e) => (
                    <div key={e.applicationID}>
                        <p>
                            <h1>CNIC Pictures</h1>
                            <embed src={`http://127.0.0.1:8000${e.nicPicFile}`} width="100%" height={'700px'} />
                        </p>
                        <p>
                            <h1>Electric Bill</h1>
                            <embed src={`http://127.0.0.1:8000${e.keBillFile}`} width="100%" height={'700px'} />
                        </p>
                        <p>
                            <h1>Gas Bill</h1>
                            <embed src={`http://127.0.0.1:8000${e.gasBillFile}`} width="100%" height={'700px'} />
                        </p>
                        <p>
                            <h1>Bank Statement</h1>
                            <embed src={`http://127.0.0.1:8000${e.bankStatementFile}`} width="100%" height={'700px'} />
                        </p>

                    </div>
                ))}
            </div>
        </>
    );
}

export default ViewDoc;