import React, { useState, useEffect } from 'react'
import axios from 'axios'
import {
    CButton,
    CCard,
    CCardBody,
    CCol,
    CForm,
    CFormInput,
    CFormLabel,
    CFormSelect,
    CRow,
} from '@coreui/react'

import DocsExample from './DocsExample';

function ViewDetails() {

    const [myData, setmyData] = useState([]);

    const allData = () => {
        axios({
            method: 'GET',
            url: "http://127.0.0.1:8000/api/ApplicationForm"
        })
            .then((response) => {
                var data = response.data;
                setmyData(data)
                console.log(data)
            }, (error) => {
                console.log(error);
            });
    }
    useEffect(() => {
        allData()
    }, [], myData.length)


    return (
        <>
            <div>
                {myData.map((item, index) => (
                    <div>
                        <CRow className='justify-content-center'>
                            <CCol md={5}>
                                <CCard className="mb-6">
                                    <CCardBody>
                                        <DocsExample href="forms/layout#gutters">
                                            <CForm className="row g-3">
                                                <h1 className='text-justify-center'>Personal Information</h1>
                                                <fieldset></fieldset>
                                                <CCol md={6}>
                                                    <CFormLabel htmlFor="inputText5">First Name</CFormLabel>
                                                    <br></br>
                                                    <CFormLabel htmlFor="inputText4">{item.FirstName}</CFormLabel>
                                                </CCol>
                                                <CCol md={6}>
                                                    <CFormLabel htmlFor="inputText5">Middle Name</CFormLabel>
                                                    <br></br>
                                                    <CFormLabel htmlFor="inputText4">{item.MiddleName}</CFormLabel>
                                                </CCol>
                                                <CCol md={6}>
                                                    <CFormLabel htmlFor="inputText4">Last Name</CFormLabel>
                                                    <br></br>
                                                    <CFormLabel htmlFor="inputText4">{item.LastName}</CFormLabel>

                                                </CCol>
                                                <CCol md={6}>
                                                    <CFormLabel htmlFor="inputText4">Father Name</CFormLabel>
                                                    <br></br>
                                                    <CFormLabel htmlFor="inputText4">{item.FatherName}</CFormLabel>

                                                </CCol>
                                                <CCol md={6}>
                                                    <CFormLabel htmlFor="inputText4">CNIC:</CFormLabel>
                                                    <br></br>
                                                    <CFormLabel htmlFor="inputText4">{item.CNIC}</CFormLabel>

                                                </CCol>

                                                <CCol md={6}>
                                                    <CFormLabel htmlFor="inputText4">Old CNIC:</CFormLabel>
                                                    <br></br>
                                                    <CFormLabel htmlFor="inputText4">{item.Old_Nic}</CFormLabel>

                                                </CCol>
                                                <CCol md={6}>
                                                    <CFormLabel htmlFor="inputText4">CNIC Issuance Date</CFormLabel>
                                                    <br></br>
                                                    <CFormLabel htmlFor="inputText4">{item.CNIC_Is_Date}</CFormLabel>

                                                </CCol>
                                                <CCol md={6}>
                                                    <CFormLabel htmlFor="inputText4">CNIC Expiry Date</CFormLabel>
                                                    <br></br>
                                                    <CFormLabel htmlFor="inputText4">{item.CNIC_Ex_Date}</CFormLabel>

                                                </CCol>
                                                <CCol md={6}>
                                                    <CFormLabel htmlFor="inputText4">Passport Number</CFormLabel>
                                                    <br></br>
                                                    <CFormLabel htmlFor="inputText4">{item.PassportNumber}</CFormLabel>

                                                </CCol>
                                                <CCol md={6}>
                                                    <CFormLabel htmlFor="inputText4">Date Of Birth</CFormLabel>
                                                    <br></br>
                                                    <CFormLabel htmlFor="inputText4">{item.DateOfBirth}</CFormLabel>

                                                </CCol>
                                                <CCol md={6}>
                                                    <CFormLabel htmlFor="inputState">Marital Status</CFormLabel>
                                                    <br></br>
                                                    <CFormLabel htmlFor="inputText4">{item.MaritalStatus}</CFormLabel>

                                                </CCol>
                                                <CCol md={6}>
                                                    <CFormLabel htmlFor="inputText4">Dependants</CFormLabel>
                                                    <CFormLabel htmlFor="inputText4">: Number Of Children</CFormLabel>
                                                    <br></br>
                                                    <CFormLabel htmlFor="inputText4">{item.Children}</CFormLabel>

                                                </CCol>
                                                <CCol md={6}>
                                                    <CFormLabel htmlFor="inputText4">Other Dependants</CFormLabel>
                                                    <br></br>
                                                    <CFormLabel htmlFor="inputText4">{item.OtherDependants}</CFormLabel>

                                                </CCol>

                                                <CCol md={6}>
                                                    <CFormLabel htmlFor="inputState">Education</CFormLabel>
                                                    <br></br>
                                                    <CFormLabel htmlFor="inputText4">{item.Education}</CFormLabel>

                                                </CCol>
                                                <CCol md={6}>
                                                    <CFormLabel htmlFor="inputState">Gender</CFormLabel>
                                                    <br></br>
                                                    <CFormLabel htmlFor="inputText4">{item.Gender}</CFormLabel>

                                                </CCol>
                                            </CForm>
                                        </DocsExample>
                                    </CCardBody>
                                </CCard>
                            </CCol>
                        </CRow>
                        <CRow className='justify-content-center'>
                            <CCol md={5}>
                                <CCard className="mb-6">
                                    <CCardBody>
                                        <DocsExample href="forms/layout#gutters">
                                            <CForm className="row g-3">
                                                <h1>Contact Info</h1>
                                                <CCol xs={12}>
                                                    <CFormLabel htmlFor="inputText4">Address</CFormLabel>
                                                    <br></br>
                                                    <CFormLabel htmlFor="inputText4">{item.address}</CFormLabel>

                                                </CCol>
                                                <CCol md={6}>
                                                    <CFormLabel htmlFor="inputText4">Postal Code</CFormLabel>
                                                    <br></br>
                                                    <CFormLabel htmlFor="inputText4">{item.postalcode}</CFormLabel>

                                                </CCol>
                                                <CCol md={6}>
                                                    <CFormLabel htmlFor="inputText4">City</CFormLabel>
                                                    <br></br>
                                                    <CFormLabel htmlFor="inputText4">{item.city}</CFormLabel>

                                                </CCol>

                                                <CCol md={6}>
                                                    <CFormLabel htmlFor="inputText4">Mobile Number</CFormLabel>
                                                    <br></br>
                                                    <CFormLabel htmlFor="inputText4">{item.mobileNumber}</CFormLabel>

                                                </CCol>
                                                <CCol md={6}>
                                                    <CFormLabel htmlFor="inputText4">Email</CFormLabel>
                                                    <br></br>
                                                    <CFormLabel htmlFor="inputText4">{item.email}</CFormLabel>

                                                </CCol>
                                                <CCol md={6}>
                                                    <CFormLabel htmlFor="inputState">Resident Type</CFormLabel>
                                                    <br></br>
                                                    <CFormLabel htmlFor="inputText4">{item.residentType}</CFormLabel>

                                                </CCol>
                                                <CCol md={6}>
                                                    <CFormLabel htmlFor="inputState">Accomodation Type</CFormLabel>
                                                    <br></br>
                                                    <CFormLabel htmlFor="inputText4">{item.accomodationType}</CFormLabel>

                                                </CCol>

                                                <CCol md={6}>
                                                    <CFormLabel htmlFor="inputText4">Monthly Rent (If Rented)</CFormLabel>
                                                    <br></br>
                                                    <CFormLabel htmlFor="inputText4">{item.monthlyRent}</CFormLabel>

                                                </CCol>
                                                <CCol md={6}>
                                                    <CFormLabel htmlFor="inputText4">Installment Amount (If Motgage)</CFormLabel>
                                                    <br></br>
                                                    <CFormLabel htmlFor="inputText4">{item.installementAmount}</CFormLabel>

                                                </CCol>

                                                <CCol xs={12}>
                                                    <CFormLabel htmlFor="inputText4">Permanent Address</CFormLabel>
                                                    <br></br>
                                                    <CFormLabel htmlFor="inputText4">{item.permanentAddress}</CFormLabel>

                                                </CCol>
                                                <CCol md={6}>
                                                    <CFormLabel htmlFor="inputText4">Postal Code (Permanent)</CFormLabel>
                                                    <br></br>
                                                    <CFormLabel htmlFor="inputText4">{item.prepostalcode}</CFormLabel>

                                                </CCol>
                                                <CCol md={6}>
                                                    <CFormLabel htmlFor="inputText4">City (Permanent)</CFormLabel>
                                                    <br></br>
                                                    <CFormLabel htmlFor="inputText4">{item.cityPer}</CFormLabel>

                                                </CCol>

                                                <CCol md={6}>
                                                    <CFormLabel htmlFor="inputState">Resident Type (Permanent)</CFormLabel>
                                                    <br></br>
                                                    <CFormLabel htmlFor="inputText4">{item.preresidentType}</CFormLabel>

                                                </CCol>

                                                <CCol mb={3}>
                                                    <CFormLabel htmlFor="inputText4">Number Of Cars</CFormLabel>
                                                    <br></br>
                                                    <CFormLabel htmlFor="inputText4">{item.numberOfCar}</CFormLabel>

                                                </CCol>

                                                <CCol md={3}>
                                                    <CFormLabel htmlFor="inputText4">Make & Model</CFormLabel>
                                                    <br></br>
                                                    <CFormLabel htmlFor="inputText4">{item.Model}</CFormLabel>

                                                </CCol>

                                            </CForm>
                                        </DocsExample>
                                    </CCardBody>
                                </CCard>
                            </CCol>
                        </CRow>
                        <CRow className='justify-content-center'>
                            <CCol md={5}>
                                <CCard className="mb-6">
                                    <CCardBody>
                                        <DocsExample href="forms/layout#gutters">
                                            <CForm className="row g-3">
                                                <h1>Employement Details </h1>
                                                <CCol md={6}>
                                                    <CFormLabel htmlFor="inputText4">Company Name</CFormLabel>
                                                    <br></br>
                                                    <CFormLabel htmlFor="inputText4">{item.C_CompnayName}</CFormLabel>

                                                </CCol>
                                                <CCol md={6}>
                                                    <CFormLabel htmlFor="inputText4">Company Address</CFormLabel>
                                                    <br></br>
                                                    <CFormLabel htmlFor="inputText4">{item.C_CompanyAddres}</CFormLabel>

                                                </CCol>
                                                <CCol md={6}>
                                                    <CFormLabel htmlFor="inputText4">Job Title</CFormLabel>
                                                    <br></br>
                                                    <CFormLabel htmlFor="inputText4">{item.C_JobTitle}</CFormLabel>

                                                </CCol>
                                                <CCol md={6}>
                                                    <CFormLabel htmlFor="inputText4">Department</CFormLabel>
                                                    <br></br>
                                                    <CFormLabel htmlFor="inputText4">{item.C_Department}</CFormLabel>

                                                </CCol>
                                                <CCol md={6}>
                                                    <CFormLabel htmlFor="inputText4">Employement Since</CFormLabel>
                                                    <br></br>
                                                    <CFormLabel htmlFor="inputText4">{item.C_EmployementSince}</CFormLabel>

                                                </CCol>
                                                <CCol md={6}>
                                                    <CFormLabel htmlFor="inputText4">Employement Number</CFormLabel>
                                                    <br></br>
                                                    <CFormLabel htmlFor="inputText4">{item.C_EmploymentNumber}</CFormLabel>

                                                </CCol>
                                                <CCol md={6}>
                                                    <CFormLabel htmlFor="inputText4">Extension</CFormLabel>
                                                    <br></br>
                                                    <CFormLabel htmlFor="inputText4">{item.C_Extension}</CFormLabel>

                                                </CCol>
                                                <CCol md={6}>
                                                    <CFormLabel htmlFor="inputText4">Office Email</CFormLabel>
                                                    <br></br>
                                                    <CFormLabel htmlFor="inputText4">{item.C_OfficeEmail}</CFormLabel>

                                                </CCol>
                                                <CCol md={6}>
                                                    <CFormLabel htmlFor="inputState">Employement Type</CFormLabel>
                                                    <br></br>
                                                    <CFormLabel htmlFor="inputText4">{item.C_EmployementType}</CFormLabel>

                                                </CCol>

                                                <h1>Previous Employement Details</h1>
                                                <CCol md={6}>
                                                    <CFormLabel htmlFor="inputText4">Company Name</CFormLabel>
                                                    <br></br>
                                                    <CFormLabel htmlFor="inputText4">{item.P_CompnayName}</CFormLabel>

                                                </CCol>
                                                <CCol md={6}>
                                                    <CFormLabel htmlFor="inputText4">Company Address</CFormLabel>
                                                    <br></br>
                                                    <CFormLabel htmlFor="inputText4">{item.P_CompanyAddres}</CFormLabel>

                                                </CCol>
                                                <CCol md={6}>
                                                    <CFormLabel htmlFor="inputText4">Job Title</CFormLabel>
                                                    <br></br>
                                                    <CFormLabel htmlFor="inputText4">{item.P_JobTitle}</CFormLabel>

                                                </CCol>
                                                <CCol md={6}>
                                                    <CFormLabel htmlFor="inputText4">Department</CFormLabel>
                                                    <br></br>
                                                    <CFormLabel htmlFor="inputText4">{item.P_Department}</CFormLabel>

                                                </CCol>
                                                <CCol md={6}>
                                                    <CFormLabel htmlFor="inputText4">Employement Period</CFormLabel>
                                                    <br></br>
                                                    <CFormLabel htmlFor="inputText4">From</CFormLabel>
                                                    <br></br>
                                                    <CFormLabel htmlFor="inputText4">{item.P_EmployementSince}</CFormLabel>

                                                </CCol>
                                                <CCol md={6}>
                                                    <CFormLabel htmlFor="inputText4">Employement Period</CFormLabel>
                                                    <br></br>
                                                    <CFormLabel htmlFor="inputText4">To</CFormLabel>
                                                    <br></br>
                                                    <CFormLabel htmlFor="inputText4">{item.P_EmployementSinceT}</CFormLabel>

                                                </CCol>
                                                <CCol md={6}>
                                                    <CFormLabel htmlFor="inputText4">Employement Number</CFormLabel>
                                                    <br></br>
                                                    <CFormLabel htmlFor="inputText4">{item.P_EmploymentNumber}</CFormLabel>

                                                </CCol>
                                                <CCol md={6}>
                                                    <CFormLabel htmlFor="inputText4">Extension</CFormLabel>
                                                    <br></br>
                                                    <CFormLabel htmlFor="inputText4">{item.P_Extension}</CFormLabel>

                                                </CCol>
                                                <CCol md={6}>
                                                    <CFormLabel htmlFor="inputText4">Office Email</CFormLabel>
                                                    <br></br>
                                                    <CFormLabel htmlFor="inputText4">{item.P_OfficeEmail}</CFormLabel>

                                                </CCol>
                                                <CCol md={6}>
                                                    <CFormLabel htmlFor="inputState">Employement Type</CFormLabel>
                                                    <br></br>
                                                    <CFormLabel htmlFor="inputText4">{item.P_EmployementType}</CFormLabel>

                                                </CCol>
                                            </CForm>
                                        </DocsExample>
                                    </CCardBody>
                                </CCard>
                            </CCol>
                        </CRow>
                        <CRow className='justify-content-center'>
                            <CCol md={5}>
                                <CCard className="mb-6">
                                    <CCardBody>
                                        <DocsExample>
                                            <CForm className="row g-3">
                                                <h1>Business Details </h1>
                                                <h4>*If Your Income Is From Business*</h4>
                                                <CCol md={6}>
                                                    <CFormLabel htmlFor="inputText4">Number Of Business</CFormLabel>
                                                    <br></br>
                                                    <CFormLabel htmlFor="inputText4">{item.numberOfBusiness}</CFormLabel>

                                                </CCol>
                                                <CCol md={6}>
                                                    <CFormLabel htmlFor="inputText4">Business Title</CFormLabel>
                                                    <br></br>
                                                    <CFormLabel htmlFor="inputText4">{item.businessTitle}</CFormLabel>

                                                </CCol>
                                                <CCol xs={12}>
                                                    <CFormLabel htmlFor="inputText4">Business Address</CFormLabel>
                                                    <br></br>
                                                    <CFormLabel htmlFor="inputText4">{item.businessAddress}</CFormLabel>

                                                </CCol>
                                                <CCol md={6}>
                                                    <CFormLabel htmlFor="inputText4">Business Type</CFormLabel>
                                                    <br></br>
                                                    <CFormLabel htmlFor="inputText4">{item.businessType}</CFormLabel>

                                                </CCol>
                                                <CCol md={6}>
                                                    <CFormLabel htmlFor="inputText4">Industry Type</CFormLabel>
                                                    <br></br>
                                                    <CFormLabel htmlFor="inputText4">{item.industryType}</CFormLabel>

                                                </CCol>
                                                <CCol md={6}>
                                                    <CFormLabel htmlFor="inputText4">Business's NTN Number</CFormLabel>
                                                    <br></br>
                                                    <CFormLabel htmlFor="inputText4">{item.ntnNumber}</CFormLabel>

                                                </CCol>
                                                <CCol md={6}>
                                                    <CFormLabel htmlFor="inputText4">Established Since</CFormLabel>
                                                    <br></br>
                                                    <CFormLabel htmlFor="inputText4">{item.establishedSince}</CFormLabel>

                                                </CCol>
                                                <CCol md={6}>
                                                    <CFormLabel htmlFor="inputText4">Register With</CFormLabel>
                                                    <br></br>
                                                    <CFormLabel htmlFor="inputText4">{item.registerWith}</CFormLabel>

                                                </CCol>
                                                <CCol md={6}>
                                                    <CFormLabel htmlFor="inputText4">Business Telephone Number</CFormLabel>
                                                    <br></br>
                                                    <CFormLabel htmlFor="inputText4">{item.businessTelephoneNumber}</CFormLabel>

                                                </CCol>
                                                <CCol md={6}>
                                                    <CFormLabel htmlFor="inputText4">Business Email</CFormLabel>
                                                    <br></br>
                                                    <br></br>

                                                    <br></br>
                                                    <CFormLabel htmlFor="inputText4">{item.businessEmail}</CFormLabel>

                                                </CCol>
                                                <CCol md={6}>
                                                    <CFormLabel htmlFor="inputText4">Self Employed Professionals (SEP):</CFormLabel>
                                                    <br></br>
                                                    <CFormLabel htmlFor="inputText4">Name Of Company</CFormLabel>
                                                    <br></br>
                                                    <CFormLabel htmlFor="inputText4">{item.companyName}</CFormLabel>

                                                </CCol>

                                                <CCol md={6}>
                                                    <CFormLabel htmlFor="inputState">Type Of Business</CFormLabel>
                                                    <br></br>
                                                    <CFormLabel htmlFor="inputText4">{item.typeOfBusiness}</CFormLabel>

                                                </CCol>

                                                <CCol md={6}>
                                                    <CFormLabel htmlFor="inputState">Professional Qualifications</CFormLabel>
                                                    <br></br>
                                                    <CFormLabel htmlFor="inputText4">{item.professionalQualifications}</CFormLabel>

                                                    <br></br>
                                                    <br></br>
                                                    <CFormLabel htmlFor="inputText4">{item.s_specify_professionalQualifications}</CFormLabel>

                                                </CCol>
                                            </CForm>
                                        </DocsExample>
                                    </CCardBody>
                                </CCard>
                            </CCol>
                        </CRow>
                        <CRow className='justify-content-center'>
                            <CCol md={5}>
                                <CCard className="mb-6">
                                    <CCardBody>
                                        <DocsExample href="forms/layout#gutters">
                                            <CForm className="row g-3">
                                                <h1>Income Details</h1>
                                                <CCol md={6}>
                                                    <CFormLabel htmlFor="inputText4">Monthly Gross Income</CFormLabel>
                                                    <br></br>
                                                    <CFormLabel htmlFor="inputText4">{item.MonthlyGrossIncome}</CFormLabel>

                                                </CCol>
                                                <CCol md={6}>
                                                    <CFormLabel htmlFor="inputText4">Monthly Net Income</CFormLabel>
                                                    <br></br>
                                                    <CFormLabel htmlFor="inputText4">{item.MonthlyNetIncome}</CFormLabel>

                                                </CCol>

                                                <CCol md={6}>
                                                    <CFormLabel htmlFor="inputText4">Salaray Disbursement Day</CFormLabel>
                                                    <br></br>
                                                    <CFormLabel htmlFor="inputText4">{item.SalarayDisbursementDay}</CFormLabel>

                                                </CCol>
                                                <CCol md={6}>
                                                    <CFormLabel htmlFor="inputText4">
                                                        Other Verifiable Income (if any) For SEP's Only
                                                    </CFormLabel>
                                                    <br></br>
                                                    <CFormLabel htmlFor="inputText4">{item.OtherVerIncome}</CFormLabel>

                                                </CCol>
                                                <CCol md={6}>
                                                    <CFormLabel htmlFor="inputText4">Source Of Other Income</CFormLabel>
                                                    <br></br>
                                                    <CFormLabel htmlFor="inputText4">{item.SourceOfOtherIncome}</CFormLabel>

                                                </CCol>
                                                <CCol md={6}>
                                                    <CFormLabel htmlFor="inputText4">Average Monthly Income</CFormLabel>
                                                    <br></br>
                                                    <CFormLabel htmlFor="inputText4">{item.AverageMonthlyIncome}</CFormLabel>

                                                </CCol>

                                                <h1>Banking Details</h1>

                                                <CCol md={6}>
                                                    <CFormLabel htmlFor="inputText4">Bank Name</CFormLabel>
                                                    <br></br>
                                                    <CFormLabel htmlFor="inputText4">{item.BankName}</CFormLabel>

                                                </CCol>
                                                <CCol md={6}>
                                                    <CFormLabel htmlFor="inputText4">Account Number</CFormLabel>
                                                    <br></br>
                                                    <CFormLabel htmlFor="inputText4">{item.AccountNumber}</CFormLabel>

                                                </CCol>

                                                <CCol md={6}>
                                                    <CFormLabel htmlFor="inputState">Account Type</CFormLabel>
                                                    <br></br>
                                                    <CFormLabel htmlFor="inputText4">{item.AccountType}</CFormLabel>

                                                </CCol>
                                                <CCol md={6}>
                                                    <CFormLabel htmlFor="inputText4">Bank Branch</CFormLabel>
                                                    <br></br>
                                                    <CFormLabel htmlFor="inputText4">{item.Branch}</CFormLabel>

                                                </CCol>

                                                <h1>Desired Financing</h1>

                                                <CCol mb={3}>
                                                    <CFormLabel htmlFor="inputText4">Ammount Sought PKR</CFormLabel>
                                                    <br></br>
                                                    <CFormLabel htmlFor="inputText4">{item.AmmountSoughtPKR}</CFormLabel>

                                                </CCol>

                                                <CCol md={6}>
                                                    <CFormLabel htmlFor="inputState">Desired Repayment Tenure</CFormLabel>
                                                    <br></br>
                                                    <CFormLabel htmlFor="inputText4">{item.DesiredRepTenure}</CFormLabel>

                                                </CCol>

                                                <CCol md={6}>
                                                    <CFormLabel htmlFor="inputState">Loan Required For</CFormLabel>
                                                    <br></br>
                                                    <CFormLabel htmlFor="inputText4">{item.LoanReqFor}</CFormLabel>

                                                </CCol>
                                            </CForm>
                                        </DocsExample>
                                    </CCardBody>
                                </CCard>
                            </CCol>
                        </CRow>
                        <CRow className='justify-content-center'>
                            <CCol md={5}>
                                <CCard className="mb-6">
                                    <CCardBody>
                                        <DocsExample href="forms/layout#gutters">
                                            <CForm className="row g-3">
                                                <h1>Details Of References</h1>
                                                <h3>Reference 01</h3>
                                                <CCol md={6}>
                                                    <CFormLabel htmlFor="inputText4">Full Name</CFormLabel>
                                                    <br></br>
                                                    <CFormLabel htmlFor="inputText4">{item.R_FullName}</CFormLabel>

                                                </CCol>
                                                <CCol md={6}>
                                                    <CFormLabel htmlFor="inputText4">CNIC</CFormLabel>
                                                    <br></br>
                                                    <CFormLabel htmlFor="inputText4">{item.R_CINC}</CFormLabel>

                                                </CCol>
                                                <CCol md={6}>
                                                    <CFormLabel htmlFor="inputText4">Passport Number</CFormLabel>
                                                    <br></br>
                                                    <CFormLabel htmlFor="inputText4">{item.R_PossportNumber}</CFormLabel>

                                                </CCol>
                                                <CCol md={6}>
                                                    <CFormLabel htmlFor="inputText4">Address</CFormLabel>
                                                    <br></br>
                                                    <CFormLabel htmlFor="inputText4">{item.R_Address}</CFormLabel>

                                                </CCol>
                                                <CCol md={6}>
                                                    <CFormLabel htmlFor="inputText4">Telephone Number Office</CFormLabel>
                                                    <br></br>
                                                    <CFormLabel htmlFor="inputText4">{item.R_TelephoneNumOffice}</CFormLabel>

                                                </CCol>
                                                <CCol md={6}>
                                                    <CFormLabel htmlFor="inputText4">Telephone Number Residence</CFormLabel>
                                                    <br></br>
                                                    <CFormLabel htmlFor="inputText4">{item.R_TelephoneNumResidence}</CFormLabel>

                                                </CCol>

                                                <CCol md={6}>
                                                    <CFormLabel htmlFor="inputText4">Email</CFormLabel>
                                                    <br></br>
                                                    <CFormLabel htmlFor="inputText4">{item.R_Email}</CFormLabel>

                                                </CCol>

                                                <CCol md={6}>
                                                    <CFormLabel htmlFor="inputText4">Cell Number</CFormLabel>
                                                    <br></br>
                                                    <CFormLabel htmlFor="inputText4">{item.R_CellNumber}</CFormLabel>

                                                </CCol>
                                                <CCol md={6}>
                                                    <CFormLabel htmlFor="inputText4">Relationship</CFormLabel>
                                                    <br></br>
                                                    <CFormLabel htmlFor="inputText4">{item.R_Relationship}</CFormLabel>

                                                </CCol>

                                                <h3>Reference 02</h3>
                                                <CCol md={6}>
                                                    <CFormLabel htmlFor="inputText4">Full Name</CFormLabel>
                                                    <br></br>
                                                    <CFormLabel htmlFor="inputText4">{item.R2_FullName}</CFormLabel>

                                                </CCol>
                                                <CCol md={6}>
                                                    <CFormLabel htmlFor="inputText4">CNIC</CFormLabel>
                                                    <br></br>
                                                    <CFormLabel htmlFor="inputText4">{item.R2_CINC}</CFormLabel>

                                                </CCol>
                                                <CCol md={6}>
                                                    <CFormLabel htmlFor="inputText4">Passport Number</CFormLabel>
                                                    <br></br>
                                                    <CFormLabel htmlFor="inputText4">{item.R2_PossportNumber}</CFormLabel>

                                                </CCol>
                                                <CCol md={6}>
                                                    <CFormLabel htmlFor="inputText4">Address</CFormLabel>
                                                    <br></br>
                                                    <CFormLabel htmlFor="inputText4">{item.R2_Address}</CFormLabel>

                                                </CCol>
                                                <CCol md={6}>
                                                    <CFormLabel htmlFor="inputText4">Telephone Number Office</CFormLabel>
                                                    <br></br>
                                                    <CFormLabel htmlFor="inputText4">{item.R2_TelephoneNumOffice}</CFormLabel>

                                                </CCol>
                                                <CCol md={6}>
                                                    <CFormLabel htmlFor="inputText4">Telephone Number Residencec</CFormLabel>
                                                    <br></br>
                                                    <CFormLabel htmlFor="inputText4">{item.R2_TelephoneNumResidence}</CFormLabel>

                                                </CCol>

                                                <CCol md={6}>
                                                    <CFormLabel htmlFor="inputText4">Email</CFormLabel>
                                                    <br></br>
                                                    <CFormLabel htmlFor="inputText4">{item.R2_Email}</CFormLabel>

                                                </CCol>

                                                <CCol md={6}>
                                                    <CFormLabel htmlFor="inputText4">Cell Number</CFormLabel>
                                                    <br></br>
                                                    <CFormLabel htmlFor="inputText4">{item.R2_CellNumber}</CFormLabel>

                                                </CCol>
                                                <CCol md={6}>
                                                    <CFormLabel htmlFor="inputText4">Relationship</CFormLabel>
                                                    <br></br>
                                                    <CFormLabel htmlFor="inputText4">{item.R2_Relationship}</CFormLabel>

                                                </CCol>
                                            </CForm>
                                        </DocsExample>
                                    </CCardBody>
                                </CCard>

                            </CCol>
                        </CRow>
                    </div>
                ))};

            </div>
        </>
    )
}
export default ViewDetails 