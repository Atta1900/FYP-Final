import React, { useState, useEffect } from 'react'
import axios from 'axios'
import {
    CButton,
    CCard,
    CCardBody,
    CCol,
    CForm,
    CFormInput,
    CFormLabel,
    CFormSelect,
    CRow,
} from '@coreui/react'
import DocsExample from './DocsExample'

//const navform1 = useNavigate()

// const [isSuccess, setSuccess] = useState(false)
// const [isError, setError] = useState(false)
// const [errorMessage, setErrorMessage] = useState('')


// const handleSubmit = (e) => {
//     e.preventDefault();
//     if (Title === "" || FirstName === "" || MiddleName === "" || LastName === "") {
//         alert("All fields are required!");
//     } else {
//         navform1("/form2");
//     }
//};
function UpdateUserData({userData}) {

 

    const [formData, setFormData] = useState({
        // Titles: '',
        FirstName: '',
        MiddleName: '',
        LastName: '',
        FatherName: '',
        CNIC: '',
        Old_Nic: '',
        CNIC_Is_Date: '',
        CNIC_Ex_Date: '',
        PassportNumber: '',
        DateOfBirth: '',
        MaritalStatus: '',
        Children: '',
        OtherDependants: '',
        Education: '',
        Gender: '',
        address: '',
        postalcode: '',
        city: '',
        mobileNumber: '',
        email: '',
        residentType: '',
        accomodationType: '',
        monthlyRent: '',
        installementAmount: '',
        permanentAddress: '',
        prepostalcode: '',
        cityPer: '',
        preresidentType: '',
        numberOfCar: '',
        Model: '',
        C_CompnayName: '',
        C_CompanyAddres: '',
        C_JobTitle: '',
        C_Department: '',
        C_EmployementSince: '',
        C_EmploymentNumber: '',
        C_Extension: '',
        C_OfficeEmail: '',
        C_EmployementType: '',
        P_CompnayName: '',
        P_CompanyAddres: '',
        P_JobTitle: '',
        P_Department: '',
        P_EmployementSince: '',
        P_EmployementSinceT: '',
        P_EmploymentNumber: '',
        P_Extension: '',
        P_OfficeEmail: '',
        P_EmployementType: '',
        MonthlyGrossIncome: '',
        MonthlyNetIncome: '',
        SalarayDisbursementDay: '',
        OtherVerIncome: '',
        SourceOfOtherIncome: '',
        AverageMonthlyIncome: '',
        BankName: '',
        AccountNumber: '',
        AccountType: '',
        Branch: '',
        DesiredRepTenure: '',
        LoanReqFor: '',
        // s_LoanReqFor: '',
        AmmountSoughtPKR: '',
        // IncomeAmountPreMonth: '',
        numberOfBusiness: '',
        businessTitle: '',
        businessAddress: '',
        businessType: '',
        industryType: '',
        ntnNumber: '',
        establishedSince: '',
        registerWith: '',
        businessTelephoneNumber: '',
        businessEmail: '',
        companyName: '',
        typeOfBusiness: '',
        s_specify_TypeOFBusiness: '',
        professionalQualifications: '',
        s_specify_professionalQualifications: '',
        R_FullName: '',
        R_CINC: '',
        R_PossportNumber: '',
        R_Address: '',
        R_TelephoneNumOffice: '',
        R_TelephoneNumResidence: '',
        R_Email: '',
        R_CellNumber: '',
        R_Relationship: '',
        R2_FullName: '',
        R2_CINC: '',
        R2_PossportNumber: '',
        R2_Address: '',
        R2_TelephoneNumOffice: '',
        R2_TelephoneNumResidence: '',
        R2_Email: '',
        R2_CellNumber: '',
        R2_Relationship: '',
        bankStatementFile: null,
        nicPicFile: null,
        keBillFile: null,
        gasBillFile: null,
        profilePicFile: null,

    });

    return (
        <>
           

                <div>

                    <CRow className='justify-content-center'>
                        <CCol md={5}>
                            <CCard className="mb-6">
                                <CCardBody>
                                    <DocsExample href="forms/layout#gutters">
                                        <CForm className="row g-3">
                                            <h1 className='text-justify-center'>Personal Information</h1>
                                            <fieldset></fieldset>
                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputText5">First Name</CFormLabel>
                                                <br></br>
                                                <CFormLabel htmlFor="inputText4">{userData?.FirstName}</CFormLabel>
                                                <CFormInput type="Text" id="inputText4" required />
                                            </CCol>
                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputText5">Middle Name</CFormLabel>
                                                <br></br>
                                                <CFormLabel htmlFor="inputText4">{userData?.MiddleName}</CFormLabel>
                                                <CFormInput type="Text" id="inputText4" required />
                                            </CCol>
                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputText4">Last Name</CFormLabel>
                                                <br></br>
                                                <CFormLabel htmlFor="inputText4">{userData?.LastName}</CFormLabel>
                                                <CFormInput type="Text" id="inputText4" required />
                                            </CCol>
                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputText4">Father Name</CFormLabel>
                                                <br></br>
                                                <CFormLabel htmlFor="inputText4">{userData?.FatherName}</CFormLabel>
                                                <CFormInput type="Text" id="inputText4" required />
                                            </CCol>
                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputText4">CNIC:</CFormLabel>
                                                <br></br>
                                                <CFormLabel htmlFor="inputText4">{userData?.CNIC}</CFormLabel>
                                                <CFormInput type="Text" id="inputText4" required />
                                            </CCol>

                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputText4">Old CNIC:</CFormLabel>
                                                <br></br>
                                                <CFormLabel htmlFor="inputText4">{userData?.Old_Nic}</CFormLabel>
                                                <CFormInput type="Text" id="inputText4" required />
                                            </CCol>
                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputText4">CNIC Issuance Date</CFormLabel>
                                                <br></br>
                                                <CFormLabel htmlFor="inputText4">{userData?.CNIC_Is_Date}</CFormLabel>
                                                <CFormInput type="Text" id="inputText4" required />
                                            </CCol>
                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputText4">CNIC Expiry Date</CFormLabel>
                                                <br></br>
                                                <CFormLabel htmlFor="inputText4">{userData?.CNIC_Ex_Date}</CFormLabel>
                                                <CFormInput type="Text" id="inputText4" required />
                                            </CCol>
                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputText4">Passport Number</CFormLabel>
                                                <br></br>
                                                <CFormLabel htmlFor="inputText4">{userData?.PassportNumber}</CFormLabel>
                                                <CFormInput type="Text" id="inputText4" required />
                                            </CCol>
                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputText4">Date Of Birth</CFormLabel>
                                                <br></br>
                                                <CFormLabel htmlFor="inputText4">{userData?.DateOfBirth}</CFormLabel>
                                                <CFormInput type="Text" id="inputText4" required />
                                            </CCol>
                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputState">Marital Status</CFormLabel>
                                                <br></br>
                                                <CFormLabel htmlFor="inputText4">{userData?.MaritalStatus}</CFormLabel>
                                                <CFormInput type="Text" id="inputText4" required />
                                            </CCol>
                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputText4">Dependants</CFormLabel>
                                                <CFormLabel htmlFor="inputText4">: Number Of Children</CFormLabel>
                                                <br></br>
                                                <CFormLabel htmlFor="inputText4">{userData?.Children}</CFormLabel>
                                                <CFormInput type="Text" id="inputText4" required />
                                            </CCol>
                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputText4">Other Dependants</CFormLabel>
                                                <br></br>
                                                <CFormLabel htmlFor="inputText4">{userData?.OtherDependants}</CFormLabel>
                                                <CFormInput type="Text" id="inputText4" required />
                                            </CCol>

                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputState">Education</CFormLabel>
                                                <br></br>
                                                <CFormLabel htmlFor="inputText4">{userData?.Education}</CFormLabel>
                                                <CFormInput type="Text" id="inputText4" required />
                                            </CCol>
                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputState">Gender</CFormLabel>
                                                <br></br>
                                                <CFormLabel htmlFor="inputText4">{userData?.Gender}</CFormLabel>
                                                <CFormInput type="Text" id="inputText4" required />
                                            </CCol>
                                        </CForm>
                                    </DocsExample>
                                </CCardBody>
                            </CCard>
                        </CCol>
                    </CRow>
                    <CRow className='justify-content-center'>
                        <CCol md={5}>
                            <CCard className="mb-6">
                                <CCardBody>
                                    <DocsExample href="forms/layout#gutters">
                                        <CForm className="row g-3">
                                            <h1>Contact Info</h1>
                                            <CCol xs={12}>
                                                <CFormLabel htmlFor="inputText4">Address</CFormLabel>
                                                <br></br>
                                                <CFormLabel htmlFor="inputText4">{userData?.address}</CFormLabel>
                                                <CFormInput type="Text" id="inputText4" required />
                                            </CCol>
                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputText4">Postal Code</CFormLabel>
                                                <br></br>
                                                <CFormLabel htmlFor="inputText4">{userData?.postalcode}</CFormLabel>
                                                <CFormInput type="Text" id="inputText4" required />
                                            </CCol>
                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputText4">City</CFormLabel>
                                                <br></br>
                                                <CFormLabel htmlFor="inputText4">{userData?.city}</CFormLabel>
                                                <CFormInput type="Text" id="inputText4" required />
                                            </CCol>

                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputText4">Mobile Number</CFormLabel>
                                                <br></br>
                                                <CFormLabel htmlFor="inputText4">{userData?.mobileNumber}</CFormLabel>
                                                <CFormInput type="Text" id="inputText4" required />
                                            </CCol>
                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputText4">Email</CFormLabel>
                                                <br></br>
                                                <CFormLabel htmlFor="inputText4">{userData?.email}</CFormLabel>
                                                <CFormInput type="Text" id="inputText4" required />
                                            </CCol>
                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputState">Resident Type</CFormLabel>
                                                <br></br>
                                                <CFormLabel htmlFor="inputText4">{userData?.residentType}</CFormLabel>
                                                <CFormInput type="Text" id="inputText4" required />
                                            </CCol>
                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputState">Accomodation Type</CFormLabel>
                                                <br></br>
                                                <CFormLabel htmlFor="inputText4">{userData?.accomodationType}</CFormLabel>
                                                <CFormInput type="Text" id="inputText4" required />
                                            </CCol>

                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputText4">Monthly Rent (If Rented)</CFormLabel>
                                                <br></br>
                                                <CFormLabel htmlFor="inputText4">{userData?.monthlyRent}</CFormLabel>
                                                <CFormInput type="Text" id="inputText4" required />
                                            </CCol>
                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputText4">Installment Amount (If Motgage)</CFormLabel>
                                                <br></br>
                                                <CFormLabel htmlFor="inputText4">{userData?.installementAmount}</CFormLabel>
                                                <CFormInput type="Text" id="inputText4" required />
                                            </CCol>

                                            <CCol xs={12}>
                                                <CFormLabel htmlFor="inputText4">Permanent Address</CFormLabel>
                                                <br></br>
                                                <CFormLabel htmlFor="inputText4">{userData?.permanentAddress}</CFormLabel>
                                                <CFormInput type="Text" id="inputText4" required />
                                            </CCol>
                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputText4">Postal Code (Permanent)</CFormLabel>
                                                <br></br>
                                                <CFormLabel htmlFor="inputText4">{userData?.prepostalcode}</CFormLabel>
                                                <CFormInput type="Text" id="inputText4" required />
                                            </CCol>
                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputText4">City (Permanent)</CFormLabel>
                                                <br></br>
                                                <CFormLabel htmlFor="inputText4">{userData?.cityPer}</CFormLabel>
                                                <CFormInput type="Text" id="inputText4" required />
                                            </CCol>

                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputState">Resident Type (Permanent)</CFormLabel>
                                                <br></br>
                                                <CFormLabel htmlFor="inputText4">{userData?.preresidentType}</CFormLabel>
                                                <CFormInput type="Text" id="inputText4" required />
                                            </CCol>

                                            <CCol mb={3}>
                                                <CFormLabel htmlFor="inputText4">Number Of Cars</CFormLabel>
                                                <br></br>
                                                <CFormLabel htmlFor="inputText4">{userData?.numberOfCar}</CFormLabel>
                                                <CFormInput type="Text" id="inputText4" required />
                                            </CCol>

                                            <CCol md={3}>
                                                <CFormLabel htmlFor="inputText4">Make & Model</CFormLabel>
                                                <br></br>
                                                <CFormLabel htmlFor="inputText4">{userData?.Model}</CFormLabel>
                                                <CFormInput type="Text" id="inputText4" required />
                                            </CCol>

                                        </CForm>
                                    </DocsExample>
                                </CCardBody>
                            </CCard>
                        </CCol>
                    </CRow>
                    <CRow className='justify-content-center'>
                        <CCol md={5}>
                            <CCard className="mb-6">
                                <CCardBody>
                                    <DocsExample href="forms/layout#gutters">
                                        <CForm className="row g-3">
                                            <h1>Employement Details </h1>
                                            <h6>For Salaried Individual Only Otherwise Filled with (-) & Go To Next Page</h6>
                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputText4">Company Name</CFormLabel>
                                                <br></br>
                                                <CFormLabel htmlFor="inputText4">{userData?.C_CompnayName}</CFormLabel>
                                                <CFormInput type="Text" id="inputText4" required />
                                            </CCol>
                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputText4">Company Address</CFormLabel>
                                                <br></br>
                                                <CFormLabel htmlFor="inputText4">{userData?.C_CompanyAddres}</CFormLabel>
                                                <CFormInput type="Text" id="inputText4" required />
                                            </CCol>
                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputText4">Job Title</CFormLabel>
                                                <br></br>
                                                <CFormLabel htmlFor="inputText4">{userData?.C_JobTitle}</CFormLabel>
                                                <CFormInput type="Text" id="inputText4" required />
                                            </CCol>
                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputText4">Department</CFormLabel>
                                                <br></br>
                                                <CFormLabel htmlFor="inputText4">{userData?.C_Department}</CFormLabel>
                                                <CFormInput type="Text" id="inputText4" required />
                                            </CCol>
                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputText4">Employement Since</CFormLabel>
                                                <br></br>
                                                <CFormLabel htmlFor="inputText4">{userData?.C_EmployementSince}</CFormLabel>
                                                <CFormInput type="Text" id="inputText4" required />
                                            </CCol>
                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputText4">Employement Number</CFormLabel>
                                                <br></br>
                                                <CFormLabel htmlFor="inputText4">{userData?.C_EmploymentNumber}</CFormLabel>
                                                <CFormInput type="Text" id="inputText4" required />
                                            </CCol>
                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputText4">Extension</CFormLabel>
                                                <br></br>
                                                <CFormLabel htmlFor="inputText4">{userData?.C_Extension}</CFormLabel>
                                                <CFormInput type="Text" id="inputText4" required />
                                            </CCol>
                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputText4">Office Email</CFormLabel>
                                                <br></br>
                                                <CFormLabel htmlFor="inputText4">{userData?.C_OfficeEmail}</CFormLabel>
                                                <CFormInput type="Text" id="inputText4" required />
                                            </CCol>
                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputState">Employement Type</CFormLabel>
                                                <br></br>
                                                <CFormLabel htmlFor="inputText4">{userData?.C_EmployementType}</CFormLabel>
                                                <CFormInput type="Text" id="inputText4" required />
                                            </CCol>

                                            <h1>Previous Employement Details</h1>
                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputText4">Company Name</CFormLabel>
                                                <br></br>
                                                <CFormLabel htmlFor="inputText4">{userData?.P_CompnayName}</CFormLabel>
                                                <CFormInput type="Text" id="inputText4" required />
                                            </CCol>
                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputText4">Company Address</CFormLabel>
                                                <br></br>
                                                <CFormLabel htmlFor="inputText4">{userData?.P_CompanyAddres}</CFormLabel>
                                                <CFormInput type="Text" id="inputText4" required />
                                            </CCol>
                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputText4">Job Title</CFormLabel>
                                                <br></br>
                                                <CFormLabel htmlFor="inputText4">{userData?.P_JobTitle}</CFormLabel>
                                                <CFormInput type="Text" id="inputText4" required />
                                            </CCol>
                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputText4">Department</CFormLabel>
                                                <br></br>
                                                <CFormLabel htmlFor="inputText4">{userData?.P_Department}</CFormLabel>
                                                <CFormInput type="Text" id="inputText4" required />
                                            </CCol>
                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputText4">Employement Period</CFormLabel>
                                                <br></br>
                                                <CFormLabel htmlFor="inputText4">From</CFormLabel>
                                                <br></br>
                                                <CFormLabel htmlFor="inputText4">{userData?.P_EmployementSince}</CFormLabel>
                                                <CFormInput type="Text" id="inputText4" required />
                                            </CCol>
                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputText4">Employement Period</CFormLabel>
                                                <br></br>
                                                <CFormLabel htmlFor="inputText4">To</CFormLabel>
                                                <br></br>
                                                <CFormLabel htmlFor="inputText4">{userData?.P_EmployementSinceT}</CFormLabel>
                                                <CFormInput type="Text" id="inputText4" required />
                                            </CCol>
                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputText4">Employement Number</CFormLabel>
                                                <br></br>
                                                <CFormLabel htmlFor="inputText4">{userData?.P_EmploymentNumber}</CFormLabel>
                                                <CFormInput type="Text" id="inputText4" required />
                                            </CCol>
                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputText4">Extension</CFormLabel>
                                                <br></br>
                                                <CFormLabel htmlFor="inputText4">{userData?.P_Extension}</CFormLabel>
                                                <CFormInput type="Text" id="inputText4" required />
                                            </CCol>
                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputText4">Office Email</CFormLabel>
                                                <br></br>
                                                <CFormLabel htmlFor="inputText4">{userData?.P_OfficeEmail}</CFormLabel>
                                                <CFormInput type="Text" id="inputText4" required />
                                            </CCol>
                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputState">Employement Type</CFormLabel>
                                                <br></br>
                                                <CFormLabel htmlFor="inputText4">{userData?.P_EmployementType}</CFormLabel>
                                                <CFormInput type="Text" id="inputText4" required />
                                            </CCol>
                                        </CForm>
                                    </DocsExample>
                                </CCardBody>
                            </CCard>
                        </CCol>
                    </CRow>
                    <CRow className='justify-content-center'>
                        <CCol md={5}>
                            <CCard className="mb-6">
                                <CCardBody>
                                    <DocsExample>
                                        <CForm className="row g-3">
                                            <h1>Business Details </h1>
                                            <h4>*If Your Income Is From Business*</h4>
                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputText4">Number Of Business</CFormLabel>
                                                <br></br>
                                                <CFormLabel htmlFor="inputText4">{userData?.numberOfBusiness}</CFormLabel>
                                                <CFormInput type="Text" id="inputText4" required />
                                            </CCol>
                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputText4">Business Title</CFormLabel>
                                                <br></br>
                                                <CFormLabel htmlFor="inputText4">{userData?.businessTitle}</CFormLabel>
                                                <CFormInput type="Text" id="inputText4" required />
                                            </CCol>
                                            <CCol xs={12}>
                                                <CFormLabel htmlFor="inputText4">Business Address</CFormLabel>
                                                <br></br>
                                                <CFormLabel htmlFor="inputText4">{userData?.businessAddress}</CFormLabel>
                                                <CFormInput type="Text" id="inputText4" required />
                                            </CCol>
                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputText4">Business Type</CFormLabel>
                                                <br></br>
                                                <CFormLabel htmlFor="inputText4">{userData?.businessType}</CFormLabel>
                                                <CFormInput type="Text" id="inputText4" required />
                                            </CCol>
                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputText4">Industry Type</CFormLabel>
                                                <br></br>
                                                <CFormLabel htmlFor="inputText4">{userData?.industryType}</CFormLabel>
                                                <CFormInput type="Text" id="inputText4" required />
                                            </CCol>
                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputText4">Business's NTN Number</CFormLabel>
                                                <br></br>
                                                <CFormLabel htmlFor="inputText4">{userData?.ntnNumber}</CFormLabel>
                                                <CFormInput type="Text" id="inputText4" required />
                                            </CCol>
                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputText4">Established Since</CFormLabel>
                                                <br></br>
                                                <CFormLabel htmlFor="inputText4">{userData?.establishedSince}</CFormLabel>
                                                <CFormInput type="Text" id="inputText4" required />
                                            </CCol>
                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputText4">Register With</CFormLabel>
                                                <br></br>
                                                <CFormLabel htmlFor="inputText4">{userData?.registerWith}</CFormLabel>
                                                <CFormInput type="Text" id="inputText4" required />
                                            </CCol>
                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputText4">Business Telephone Number</CFormLabel>
                                                <br></br>
                                                <CFormLabel htmlFor="inputText4">{userData?.businessTelephoneNumber}</CFormLabel>
                                                <CFormInput type="Text" id="inputText4" required />
                                            </CCol>
                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputText4">Business Email</CFormLabel>
                                                <br></br>
                                                <br></br>

                                                <br></br>
                                                <CFormLabel htmlFor="inputText4">{userData?.businessEmail}</CFormLabel>
                                                <CFormInput type="Text" id="inputText4" required />
                                            </CCol>
                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputText4">Self Employed Professionals (SEP):</CFormLabel>
                                                <br></br>
                                                <CFormLabel htmlFor="inputText4">Name Of Company</CFormLabel>
                                                <br></br>
                                                <CFormLabel htmlFor="inputText4">{userData?.companyName}</CFormLabel>
                                                <CFormInput type="Text" id="inputText4" required />
                                            </CCol>

                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputState">Type Of Business</CFormLabel>
                                                <br></br>
                                                <CFormLabel htmlFor="inputText4">{userData?.typeOfBusiness}</CFormLabel>
                                                <CFormInput type="Text" id="inputText4" required />
                                            </CCol>

                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputState">Professional Qualifications</CFormLabel>
                                                <br></br>
                                                <CFormLabel htmlFor="inputText4">{userData?.professionalQualifications}</CFormLabel>
                                                <CFormInput type="Text" id="inputText4" required />
                                                <br></br>
                                                <br></br>
                                                <CFormLabel htmlFor="inputText4">{userData?.s_specify_professionalQualifications}</CFormLabel>
                                                <CFormInput type="Text" id="inputText4" required />
                                            </CCol>
                                        </CForm>
                                    </DocsExample>
                                </CCardBody>
                            </CCard>
                        </CCol>
                    </CRow>
                    <CRow className='justify-content-center'>
                        <CCol md={5}>
                            <CCard className="mb-6">
                                <CCardBody>
                                    <DocsExample href="forms/layout#gutters">
                                        <CForm className="row g-3">
                                            <h1>Income Details</h1>
                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputText4">Monthly Gross Income</CFormLabel>
                                                <br></br>
                                                <CFormLabel htmlFor="inputText4">{userData?.MonthlyGrossIncome}</CFormLabel>
                                                <CFormInput type="Text" id="inputText4" required />
                                            </CCol>
                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputText4">Monthly Net Income</CFormLabel>
                                                <br></br>
                                                <CFormLabel htmlFor="inputText4">{userData?.MonthlyNetIncome}</CFormLabel>
                                                <CFormInput type="Text" id="inputText4" required />
                                            </CCol>

                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputText4">Salaray Disbursement Day</CFormLabel>
                                                <br></br>
                                                <CFormLabel htmlFor="inputText4">{userData?.SalarayDisbursementDay}</CFormLabel>
                                                <CFormInput type="Text" id="inputText4" required />
                                            </CCol>
                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputText4">
                                                    Other Verifiable Income (if any) For SEP's Only
                                                </CFormLabel>
                                                <br></br>
                                                <CFormLabel htmlFor="inputText4">{userData?.OtherVerIncome}</CFormLabel>
                                                <CFormInput type="Text" id="inputText4" required />
                                            </CCol>
                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputText4">Source Of Other Income</CFormLabel>
                                                <br></br>
                                                <CFormLabel htmlFor="inputText4">{userData?.SourceOfOtherIncome}</CFormLabel>
                                                <CFormInput type="Text" id="inputText4" required />
                                            </CCol>
                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputText4">Average Monthly Income</CFormLabel>
                                                <br></br>
                                                <CFormLabel htmlFor="inputText4">{userData?.AverageMonthlyIncome}</CFormLabel>
                                                <CFormInput type="Text" id="inputText4" required />
                                            </CCol>

                                            <h1>Banking Details</h1>

                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputText4">Bank Name</CFormLabel>
                                                <br></br>
                                                <CFormLabel htmlFor="inputText4">{userData?.BankName}</CFormLabel>
                                                <CFormInput type="Text" id="inputText4" required />
                                            </CCol>
                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputText4">Account Number</CFormLabel>
                                                <br></br>
                                                <CFormLabel htmlFor="inputText4">{userData?.AccountNumber}</CFormLabel>
                                                <CFormInput type="Text" id="inputText4" required />
                                            </CCol>

                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputState">Account Type</CFormLabel>
                                                <br></br>
                                                <CFormLabel htmlFor="inputText4">{userData?.AccountType}</CFormLabel>
                                                <CFormInput type="Text" id="inputText4" required />
                                            </CCol>
                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputText4">Bank Branch</CFormLabel>
                                                <br></br>
                                                <CFormLabel htmlFor="inputText4">{userData?.Branch}</CFormLabel>
                                                <CFormInput type="Text" id="inputText4" required />
                                            </CCol>

                                            <h1>Desired Financing</h1>

                                            <CCol mb={3}>
                                                <CFormLabel htmlFor="inputText4">Ammount Sought PKR</CFormLabel>
                                                <br></br>
                                                <CFormLabel htmlFor="inputText4">{userData?.AmmountSoughtPKR}</CFormLabel>
                                                <CFormInput type="Text" id="inputText4" required />
                                            </CCol>

                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputState">Desired Repayment Tenure</CFormLabel>
                                                <br></br>
                                                <CFormLabel htmlFor="inputText4">{userData?.DesiredRepTenure}</CFormLabel>
                                                <CFormInput type="Text" id="inputText4" required />
                                            </CCol>

                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputState">Loan Required For</CFormLabel>
                                                <br></br>
                                                <CFormLabel htmlFor="inputText4">{userData?.LoanReqFor}</CFormLabel>
                                                <CFormInput type="Text" id="inputText4" required />
                                            </CCol>
                                        </CForm>
                                    </DocsExample>
                                </CCardBody>
                            </CCard>
                        </CCol>
                    </CRow>
                    <CRow className='justify-content-center'>
                        <CCol md={5}>
                            <CCard className="mb-6">
                                <CCardBody>
                                    <DocsExample href="forms/layout#gutters">
                                        <CForm className="row g-3">
                                            <h1>Details Of References</h1>
                                            <h3>Reference 01</h3>
                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputText4">Full Name</CFormLabel>
                                                <br></br>
                                                <CFormLabel htmlFor="inputText4">{userData?.R_FullName}</CFormLabel>
                                                <CFormInput type="Text" id="inputText4" required />
                                            </CCol>
                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputText4">CNIC</CFormLabel>
                                                <br></br>
                                                <CFormLabel htmlFor="inputText4">{userData?.R_CINC}</CFormLabel>
                                                <CFormInput type="Text" id="inputText4" required />
                                            </CCol>
                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputText4">Passport Number</CFormLabel>
                                                <br></br>
                                                <CFormLabel htmlFor="inputText4">{userData?.R_PossportNumber}</CFormLabel>
                                                <CFormInput type="Text" id="inputText4" required />
                                            </CCol>
                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputText4">Address</CFormLabel>
                                                <br></br>
                                                <CFormLabel htmlFor="inputText4">{userData?.R_Address}</CFormLabel>
                                                <CFormInput type="Text" id="inputText4" required />
                                            </CCol>
                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputText4">Telephone Number Office</CFormLabel>
                                                <br></br>
                                                <CFormLabel htmlFor="inputText4">{userData?.R_TelephoneNumOffice}</CFormLabel>
                                                <CFormInput type="Text" id="inputText4" required />
                                            </CCol>
                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputText4">Telephone Number Residence</CFormLabel>
                                                <br></br>
                                                <CFormLabel htmlFor="inputText4">{userData?.R_TelephoneNumResidence}</CFormLabel>
                                                <CFormInput type="Text" id="inputText4" required />
                                            </CCol>

                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputText4">Email</CFormLabel>
                                                <br></br>
                                                <CFormLabel htmlFor="inputText4">{userData?.R_Email}</CFormLabel>
                                                <CFormInput type="Text" id="inputText4" required />
                                            </CCol>

                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputText4">Cell Number</CFormLabel>
                                                <br></br>
                                                <CFormLabel htmlFor="inputText4">{userData?.R_CellNumber}</CFormLabel>
                                                <CFormInput type="Text" id="inputText4" required />
                                            </CCol>
                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputText4">Relationship</CFormLabel>
                                                <br></br>
                                                <CFormLabel htmlFor="inputText4">{userData?.R_Relationship}</CFormLabel>
                                                <CFormInput type="Text" id="inputText4" required />
                                            </CCol>

                                            <h3>Reference 02</h3>
                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputText4">Full Name</CFormLabel>
                                                <br></br>
                                                <CFormLabel htmlFor="inputText4">{userData?.R2_FullName}</CFormLabel>
                                                <CFormInput type="Text" id="inputText4" required />
                                            </CCol>
                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputText4">CNIC</CFormLabel>
                                                <br></br>
                                                <CFormLabel htmlFor="inputText4">{userData?.R2_CINC}</CFormLabel>
                                                <CFormInput type="Text" id="inputText4" required />
                                            </CCol>
                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputText4">Passport Number</CFormLabel>
                                                <br></br>
                                                <CFormLabel htmlFor="inputText4">{userData?.R2_PossportNumber}</CFormLabel>
                                                <CFormInput type="Text" id="inputText4" required />
                                            </CCol>
                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputText4">Address</CFormLabel>
                                                <br></br>
                                                <CFormLabel htmlFor="inputText4">{userData?.R2_Address}</CFormLabel>
                                                <CFormInput type="Text" id="inputText4" required />
                                            </CCol>
                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputText4">Telephone Number Office</CFormLabel>
                                                <br></br>
                                                <CFormLabel htmlFor="inputText4">{userData?.R2_TelephoneNumOffice}</CFormLabel>
                                                <CFormInput type="Text" id="inputText4" required />
                                            </CCol>
                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputText4">Telephone Number Residencec</CFormLabel>
                                                <br></br>
                                                <CFormLabel htmlFor="inputText4">{userData?.R2_TelephoneNumResidence}</CFormLabel>
                                                <CFormInput type="Text" id="inputText4" required />
                                            </CCol>

                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputText4">Email</CFormLabel>
                                                <br></br>
                                                <CFormLabel htmlFor="inputText4">{userData?.R2_Email}</CFormLabel>
                                                <CFormInput type="Text" id="inputText4" required />
                                            </CCol>

                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputText4">Cell Number</CFormLabel>
                                                <br></br>
                                                <CFormLabel htmlFor="inputText4">{userData?.R2_CellNumber}</CFormLabel>
                                                <CFormInput type="Text" id="inputText4" required />
                                            </CCol>
                                            <CCol md={6}>
                                                <CFormLabel htmlFor="inputText4">Relationship</CFormLabel>
                                                <br></br>
                                                <CFormLabel htmlFor="inputText4">{userData?.R2_Relationship}</CFormLabel>
                                                <CFormInput type="Text" id="inputText4" required />
                                            </CCol>
                                        </CForm>
                                    </DocsExample>
                                </CCardBody>
                            </CCard>

                        </CCol>
                    </CRow>
                </div>

            

        </>
    );
}
export default UpdateUserData