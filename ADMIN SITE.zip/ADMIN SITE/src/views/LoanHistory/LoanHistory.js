import React, { useState, useEffect, useRef } from 'react'
import axios from 'axios'
import {
    CAvatar,
    CButton,
    CButtonGroup,
    CCard,
    CCardBody,
    CCardFooter,
    CCardHeader,
    CCol,
    CProgress,
    CRow,
    CTable,
    CTableBody,
    CTableDataCell,
    CTableHead,
    CTableHeaderCell,
    CTableRow,
} from '@coreui/react'
import { CChartLine } from '@coreui/react-chartjs'
import { getStyle, hexToRgba } from '@coreui/utils'
import CIcon from '@coreui/icons-react'
import { jsPDF } from 'jspdf'
import {
    cibGoogle,
    cibFacebook,
    cibLinkedin,
    cibTwitter,
    cilCloudDownload,
    cilPeople,
    cilUser,
    cilUserFemale,
} from '@coreui/icons'

import avatar1 from 'src/assets/images/avatars/1.jpg'
import avatar2 from 'src/assets/images/avatars/2.jpg'
import avatar3 from 'src/assets/images/avatars/3.jpg'
import avatar4 from 'src/assets/images/avatars/4.jpg'

import avatar6 from 'src/assets/images/avatars/6.jpg'
import avatar7 from 'src/assets/images/avatars/7.jpg'
import avatar8 from 'src/assets/images/avatars/8.jpg'
import avatar9 from 'src/assets/images/avatars/9.jpg'

const LoanHistory = () => {

    const [myData, setmyData] = useState([]);

    const allData = () => {
        axios({
            method: 'GET',
            url: "http://127.0.0.1:8000/api/ApplicationForm"
        })
            .then((response) => {
                var data = response.data;
                setmyData(data)
                console.log(data)

            }, (error) => {
                console.log(error);


            });
    }
    const content = useRef(null)

    useEffect(() => {
        allData()
    }, myData.length)

    const printTable = () => {
        // const doc = new jsPDF();
        // const d = content.current.innerHTML;
        // doc.html(d)
        // doc.save("records.pdf");
        // console.log(content.current.innerHTML)
        const printContents = content.current.innerHTML;
        // const originalContents = document.body.innerHTML;

        document.body.innerHTML = printContents;
        window.print();
        // document.body.innerHTML = originalContents;

    }

    return (
        <>
            <h1>LOAN HISTORY OF APPLICANTS</h1>
            <CRow>
                <CCol xs>
                    <CCard className="mb-4">
                        <CCardBody>
                            <div>
                                <CButton class="btn btn-outline-primary" onClick={() => printTable()} type='button'>Print Statement</CButton>
                            </div>
                            <CTable ref={content} align="middle" className="mb-0 border" hover responsive>
                                <CTableHead color="light">
                                    <CTableRow>
                                        <CTableHeaderCell className="text-center">
                                            <CIcon icon={cilPeople} />
                                        </CTableHeaderCell>
                                        <CTableHeaderCell>Application No.</CTableHeaderCell>
                                        <CTableHeaderCell className="text-center">Name</CTableHeaderCell>
                                        <CTableHeaderCell className="text-center">Total Loan Amount</CTableHeaderCell>
                                        <CTableHeaderCell className="text-center">Total Paid Amount</CTableHeaderCell>
                                        <CTableHeaderCell className="text-center">Balance Amount</CTableHeaderCell>
                                        <CTableHeaderCell className="text-center">Installment Amount</CTableHeaderCell>
                                        <CTableHeaderCell className="text-center">Interest Rate</CTableHeaderCell>
                                        <CTableHeaderCell className="text-center">Date Of Installment</CTableHeaderCell>
                                        <CTableHeaderCell className="text-center">Action</CTableHeaderCell>

                                    </CTableRow>
                                </CTableHead>
                                <CTableBody>
                                    {myData.map((item, index) => (

                                        <CTableRow v-for="item in tableItems" key={index}>
                                            <CTableDataCell className="text-center">
                                                <CAvatar size="md" src={`http://127.0.0.1:8000${item.profilePicFile}`} />

                                            </CTableDataCell>
                                            <CTableDataCell className="text-center">
                                                <div>{item.applicationID}</div>
                                            </CTableDataCell>
                                            <CTableDataCell className="text-center">
                                                <div>{item.FirstName} {item.LastName}</div>
                                            </CTableDataCell>
                                            <CTableDataCell className="text-center">
                                                <div>{item.AmmountSoughtPKR}</div>
                                            </CTableDataCell>
                                            <CTableDataCell className="text-center">
                                                <div>{item.AmmountSoughtPKR * 1.13}  </div>
                                            </CTableDataCell>
                                            <CTableDataCell className="text-center">
                                                <div>{item.AmmountSoughtPKR - item.installementAmount}</div>
                                            </CTableDataCell>
                                            <CTableDataCell className="text-center">
                                                <div>{item.AmmountSoughtPKR * 1.13 / item.DesiredRepTenure}</div>
                                            </CTableDataCell>
                                            <CTableDataCell className="text-center">
                                                <div>13%</div>
                                            </CTableDataCell>
                                            <CTableDataCell className="text-center">
                                                <div>{item.SalarayDisbursementDay}</div>
                                            </CTableDataCell>
                                            <CTableDataCell>
                                                <div>
                                                    <CButton class="btn btn-outline-primary" type='button'>Print Statement</CButton>
                                                </div>
                                            </CTableDataCell>
                                        </CTableRow>
                                    ))};
                                </CTableBody>
                            </CTable>
                        </CCardBody>
                    </CCard>
                </CCol>
            </CRow>
        </>
    )
};
export default LoanHistory