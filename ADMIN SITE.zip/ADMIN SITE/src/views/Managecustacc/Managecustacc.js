import React, { useState, useEffect } from 'react'
import axios from 'axios'
import {
    CButton,
    CCard,
    CCardBody,
    CCardFooter,
    CCardGroup,
    CCardHeader,
    CCardImage,
    CCardLink,
    CCardSubtitle,
    CCardText,
    CCardTitle,
    CListGroup,
    CListGroupItem,
    CNav,
    CNavItem,
    CNavLink,
    CCol,
    CRow,
    CModal,
  CModalBody,
  CModalHeader,
  CModalTitle,
  CModalFooter,
} from '@coreui/react'
import { DocsExample } from 'src/components'
import UpdateUser from 'src/components/UpdateUser'

//import ReactImg from 'src/assets/images/Atta.jpg'

const Managecustacc = () => {
    const [visible, setVisible] = useState(false)
    const [myData, setmyData] = useState([]);
    const [userData, setUserData] = useState(null);

    const allData = () => {

        axios({
            method: 'GET',
            url: "http://127.0.0.1:8000/api/ApplicationForm"
        })
            .then((response) => {
                var data = response.data;
                setmyData(data)
                console.log(data)

            }, (error) => {
                console.log(error)

            });
    }
    useEffect(() => {
        allData();
    }, myData.length)


 const deleteApplication = async (id) => {
       

        axios({
            method: 'DELETE',
            url: `http://localhost:8000/api/UpdateStuatus/${id}`,
           

        })
            .then((response) => {
               
                allData();
                alert("Application  has been Deleted")

            }, (error) => {
                console.log(error);

            });
      
    }
const updateUser=(item)=>{
    setUserData(item)
    setVisible(true)
}
    return (
        <>
            <DocsExample href="components/cards/#grid-cards">
                <CRow xs={{ cols: 1, gutter: 4 }} md={{ cols: 3 }}>
                    {myData.map((item, index) => (
                        <CCard key={index}>
                            <div>
                                <CCardImage orientation="top" src={`http://127.0.0.1:8000${item.profilePicFile}`} style={{ width: "25rem", height: "25rem" }} alt="Image" />
                            </div>
                            <CCardBody>
                                <CCardTitle>{item.FirstName} {item.LastName}</CCardTitle>
                            </CCardBody>
                            <CListGroup>
                                <CListGroupItem>{item.applicationID}</CListGroupItem>
                                <CListGroupItem> {item.P_EmployementSince}</CListGroupItem>
                                <CListGroupItem>{item.DesiredRepTenure} Months</CListGroupItem>
                                <CListGroupItem> RS: {item.AmmountSoughtPKR}</CListGroupItem>
                            </CListGroup>
                            <CCardBody>
                                <CCardLink href=""> {item.installementAmount}</CCardLink>
                            </CCardBody>
                            <CCardBody>
                                <CButton href="#" class="btn btn-outline-primary" type='button' onClick={()=>updateUser(item)}>Update</CButton>
                                <CButton  class="btn btn-outline-danger" onClick={()=>deleteApplication(item.applicationID)} type='button'>Delete</CButton>
                            </CCardBody>
                        </CCard>
                    ))};
                </CRow>
            </DocsExample>
            <CModal size="xl" visible={visible} onClose={() => setVisible(false)}>
        <CModalHeader>
          <CModalTitle>Update User</CModalTitle>
        </CModalHeader>
        <CModalBody>
            <UpdateUser userData={userData} />
            </CModalBody>
        <CModalFooter>
          <CButton color="secondary" onClick={() => setVisible(false)}>
            Close
          </CButton>
        </CModalFooter>
      </CModal>


        </>
    )
}
export default Managecustacc