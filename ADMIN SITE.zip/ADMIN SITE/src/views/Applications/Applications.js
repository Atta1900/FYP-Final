import React, { useState, useEffect } from 'react'
import axios from 'axios'
import {
  CAvatar,
  CButton,
  CCard,
  CCardBody,
  CForm,
  CFormLabel,
  CCol,
  CRow,
  CTable,
  CTableBody,
  CTableDataCell,
  CTableHead,
  CTableHeaderCell,
  CTableRow,
  CModal,
  CModalBody,
  CModalHeader,
  CModalTitle,
  CModalFooter,
} from '@coreui/react'
import CIcon from '@coreui/icons-react'
import {
  cilPeople,
} from '@coreui/icons'
import { DocsExample } from 'src/components'
import ViewDetails from 'src/components/ViewDetails'
import avatar1 from 'src/assets/images/avatars/1.jpg'
import avatar2 from 'src/assets/images/avatars/2.jpg'
import avatar3 from 'src/assets/images/avatars/3.jpg'
import avatar4 from 'src/assets/images/avatars/4.jpg'
import avatar5 from 'src/assets/images/avatars/5.jpg'
import avatar6 from 'src/assets/images/avatars/6.jpg'
import avatar7 from 'src/assets/images/avatars/7.jpg'
import avatar8 from 'src/assets/images/avatars/8.jpg'
import avatar9 from 'src/assets/images/avatars/9.jpg'



const Application = () => {
  const random = (min, max) => Math.floor(Math.random() * (max - min + 1) + min)
  const [myData, setmyData] = useState([]);
  const [singleItem, setSingleItem] = useState(null);
  const [visible, setVisible] = useState(false)

  const allData = () => {

    axios({
      method: 'GET',
      url: "http://127.0.0.1:8000/api/ApplicationForm"
    })
      .then((response) => {
        var data = response.data;
        setmyData(data)
        console.log(data)

      }, (error) => {
        console.log(error);

      });
  }
  useEffect(() => {
    allData();
  }, [], myData.length)
const singleItemData=(data)=>{
  setVisible(true)
  setSingleItem(data)
}
  return (
    <>
      <CRow>
        <CCol xs>
          <CCard className="mb-4">
            <h1> Pending Applications</h1>
            <CCardBody>
              <CTable align="middle" className="mb-0 border" hover responsive>
                <CTableHead color="light">
                  <CTableRow>
                    <CTableHeaderCell className="text-center">
                      <CIcon icon={cilPeople} />
                    </CTableHeaderCell>
                    <CTableHeaderCell className="text-center">Name</CTableHeaderCell>
                    <CTableHeaderCell className="text-center">Application No.</CTableHeaderCell>
                    <CTableHeaderCell className="text-center">Loan Amount</CTableHeaderCell>
                    <CTableHeaderCell className="text-center">Date</CTableHeaderCell>
                    <CTableHeaderCell className="text-center">View Application Form</CTableHeaderCell>
                  </CTableRow>
                </CTableHead>
                <CTableBody>
                  {myData.map((item, index) => (
                    <CTableRow v-for="item in tableItems" key={index}>
                      <CTableDataCell className="text-center">
                        <CAvatar size="md" src={`http://127.0.0.1:8000${item.profilePicFile}`} />
                      </CTableDataCell>
                      <CTableDataCell className="text-center">
                        <div>{item.applicationID}</div>
                      </CTableDataCell>
                      <CTableDataCell className="text-center">
                        <div>{item.FirstName} {item.LastName}</div>
                      </CTableDataCell>
                      <CTableDataCell className="text-center">
                        <div>{item.AmmountSoughtPKR}</div>
                      </CTableDataCell>
                      <CTableDataCell className="text-center">
                        <div>{item.DateOfBirth}</div>
                      </CTableDataCell>
                      <CTableDataCell className="text-center">
                        <div>
                          <CButton class="btn btn-large btn-outline-primary" type='button' onClick={() => singleItemData(item)}> View </CButton>
                        </div>
                      </CTableDataCell>
                    </CTableRow>
                  ))}
                </CTableBody>
              </CTable>
            </CCardBody>
          </CCard>
        </CCol>
      </CRow>
      <CModal size="xl" visible={visible} onClose={() => setVisible(false)}>
        <CModalHeader>
          <CModalTitle>User Documents</CModalTitle>
        </CModalHeader>
        <CModalBody>
          <div>
         
              <div>
                <CRow className='justify-content-center'>
                  <CCol md={5}>
                    <CCard className="mb-6">
                      <CCardBody>
                        <DocsExample href="forms/layout#gutters">
                          <CForm className="row g-3">
                            <h1 className='text-justify-center'>Personal Information</h1>
                            <fieldset></fieldset>
                            <CCol md={6}>
                              <CFormLabel htmlFor="inputText5">First Name</CFormLabel>
                              <br></br>
                              <CFormLabel htmlFor="inputText4">{singleItem?.FirstName}</CFormLabel>
                            </CCol>
                            <CCol md={6}>
                              <CFormLabel htmlFor="inputText5">Middle Name</CFormLabel>
                              <br></br>
                              <CFormLabel htmlFor="inputText4">{singleItem?.MiddleName}</CFormLabel>
                            </CCol>
                            <CCol md={6}>
                              <CFormLabel htmlFor="inputText4">Last Name</CFormLabel>
                              <br></br>
                              <CFormLabel htmlFor="inputText4">{singleItem?.LastName}</CFormLabel>

                            </CCol>
                            <CCol md={6}>
                              <CFormLabel htmlFor="inputText4">Father Name</CFormLabel>
                              <br></br>
                              <CFormLabel htmlFor="inputText4">{singleItem?.FatherName}</CFormLabel>

                            </CCol>
                            <CCol md={6}>
                              <CFormLabel htmlFor="inputText4">CNIC:</CFormLabel>
                              <br></br>
                              <CFormLabel htmlFor="inputText4">{singleItem?.CNIC}</CFormLabel>

                            </CCol>

                            <CCol md={6}>
                              <CFormLabel htmlFor="inputText4">Old CNIC:</CFormLabel>
                              <br></br>
                              <CFormLabel htmlFor="inputText4">{singleItem?.Old_Nic}</CFormLabel>

                            </CCol>
                            <CCol md={6}>
                              <CFormLabel htmlFor="inputText4">CNIC Issuance Date</CFormLabel>
                              <br></br>
                              <CFormLabel htmlFor="inputText4">{singleItem?.CNIC_Is_Date}</CFormLabel>

                            </CCol>
                            <CCol md={6}>
                              <CFormLabel htmlFor="inputText4">CNIC Expiry Date</CFormLabel>
                              <br></br>
                              <CFormLabel htmlFor="inputText4">{singleItem?.CNIC_Ex_Date}</CFormLabel>

                            </CCol>
                            <CCol md={6}>
                              <CFormLabel htmlFor="inputText4">Passport Number</CFormLabel>
                              <br></br>
                              <CFormLabel htmlFor="inputText4">{singleItem?.PassportNumber}</CFormLabel>

                            </CCol>
                            <CCol md={6}>
                              <CFormLabel htmlFor="inputText4">Date Of Birth</CFormLabel>
                              <br></br>
                              <CFormLabel htmlFor="inputText4">{singleItem?.DateOfBirth}</CFormLabel>

                            </CCol>
                            <CCol md={6}>
                              <CFormLabel htmlFor="inputState">Marital Status</CFormLabel>
                              <br></br>
                              <CFormLabel htmlFor="inputText4">{singleItem?.MaritalStatus}</CFormLabel>

                            </CCol>
                            <CCol md={6}>
                              <CFormLabel htmlFor="inputText4">Dependants</CFormLabel>
                              <CFormLabel htmlFor="inputText4">: Number Of Children</CFormLabel>
                              <br></br>
                              <CFormLabel htmlFor="inputText4">{singleItem?.Children}</CFormLabel>

                            </CCol>
                            <CCol md={6}>
                              <CFormLabel htmlFor="inputText4">Other Dependants</CFormLabel>
                              <br></br>
                              <CFormLabel htmlFor="inputText4">{singleItem?.OtherDependants}</CFormLabel>

                            </CCol>

                            <CCol md={6}>
                              <CFormLabel htmlFor="inputState">Education</CFormLabel>
                              <br></br>
                              <CFormLabel htmlFor="inputText4">{singleItem?.Education}</CFormLabel>

                            </CCol>
                            <CCol md={6}>
                              <CFormLabel htmlFor="inputState">Gender</CFormLabel>
                              <br></br>
                              <CFormLabel htmlFor="inputText4">{singleItem?.Gender}</CFormLabel>

                            </CCol>
                          </CForm>
                        </DocsExample>
                      </CCardBody>
                    </CCard>
                  </CCol>
                </CRow>
                <CRow className='justify-content-center'>
                  <CCol md={5}>
                    <CCard className="mb-6">
                      <CCardBody>
                        <DocsExample href="forms/layout#gutters">
                          <CForm className="row g-3">
                            <h1>Contact Info</h1>
                            <CCol xs={12}>
                              <CFormLabel htmlFor="inputText4">Address</CFormLabel>
                              <br></br>
                              <CFormLabel htmlFor="inputText4">{singleItem?.address}</CFormLabel>

                            </CCol>
                            <CCol md={6}>
                              <CFormLabel htmlFor="inputText4">Postal Code</CFormLabel>
                              <br></br>
                              <CFormLabel htmlFor="inputText4">{singleItem?.postalcode}</CFormLabel>

                            </CCol>
                            <CCol md={6}>
                              <CFormLabel htmlFor="inputText4">City</CFormLabel>
                              <br></br>
                              <CFormLabel htmlFor="inputText4">{singleItem?.city}</CFormLabel>

                            </CCol>

                            <CCol md={6}>
                              <CFormLabel htmlFor="inputText4">Mobile Number</CFormLabel>
                              <br></br>
                              <CFormLabel htmlFor="inputText4">{singleItem?.mobileNumber}</CFormLabel>

                            </CCol>
                            <CCol md={6}>
                              <CFormLabel htmlFor="inputText4">Email</CFormLabel>
                              <br></br>
                              <CFormLabel htmlFor="inputText4">{singleItem?.email}</CFormLabel>

                            </CCol>
                            <CCol md={6}>
                              <CFormLabel htmlFor="inputState">Resident Type</CFormLabel>
                              <br></br>
                              <CFormLabel htmlFor="inputText4">{singleItem?.residentType}</CFormLabel>

                            </CCol>
                            <CCol md={6}>
                              <CFormLabel htmlFor="inputState">Accomodation Type</CFormLabel>
                              <br></br>
                              <CFormLabel htmlFor="inputText4">{singleItem?.accomodationType}</CFormLabel>

                            </CCol>

                            <CCol md={6}>
                              <CFormLabel htmlFor="inputText4">Monthly Rent (If Rented)</CFormLabel>
                              <br></br>
                              <CFormLabel htmlFor="inputText4">{singleItem?.monthlyRent}</CFormLabel>

                            </CCol>
                            <CCol md={6}>
                              <CFormLabel htmlFor="inputText4">Installment Amount (If Motgage)</CFormLabel>
                              <br></br>
                              <CFormLabel htmlFor="inputText4">{singleItem?.installementAmount}</CFormLabel>

                            </CCol>

                            <CCol xs={12}>
                              <CFormLabel htmlFor="inputText4">Permanent Address</CFormLabel>
                              <br></br>
                              <CFormLabel htmlFor="inputText4">{singleItem?.permanentAddress}</CFormLabel>

                            </CCol>
                            <CCol md={6}>
                              <CFormLabel htmlFor="inputText4">Postal Code (Permanent)</CFormLabel>
                              <br></br>
                              <CFormLabel htmlFor="inputText4">{singleItem?.prepostalcode}</CFormLabel>

                            </CCol>
                            <CCol md={6}>
                              <CFormLabel htmlFor="inputText4">City (Permanent)</CFormLabel>
                              <br></br>
                              <CFormLabel htmlFor="inputText4">{singleItem?.cityPer}</CFormLabel>

                            </CCol>

                            <CCol md={6}>
                              <CFormLabel htmlFor="inputState">Resident Type (Permanent)</CFormLabel>
                              <br></br>
                              <CFormLabel htmlFor="inputText4">{singleItem?.preresidentType}</CFormLabel>

                            </CCol>

                            <CCol mb={3}>
                              <CFormLabel htmlFor="inputText4">Number Of Cars</CFormLabel>
                              <br></br>
                              <CFormLabel htmlFor="inputText4">{singleItem?.numberOfCar}</CFormLabel>

                            </CCol>

                            <CCol md={3}>
                              <CFormLabel htmlFor="inputText4">Make & Model</CFormLabel>
                              <br></br>
                              <CFormLabel htmlFor="inputText4">{singleItem?.Model}</CFormLabel>

                            </CCol>

                          </CForm>
                        </DocsExample>
                      </CCardBody>
                    </CCard>
                  </CCol>
                </CRow>
                <CRow className='justify-content-center'>
                  <CCol md={5}>
                    <CCard className="mb-6">
                      <CCardBody>
                        <DocsExample href="forms/layout#gutters">
                          <CForm className="row g-3">
                            <h1>Employement Details </h1>
                            <CCol md={6}>
                              <CFormLabel htmlFor="inputText4">Company Name</CFormLabel>
                              <br></br>
                              <CFormLabel htmlFor="inputText4">{singleItem?.C_CompnayName}</CFormLabel>

                            </CCol>
                            <CCol md={6}>
                              <CFormLabel htmlFor="inputText4">Company Address</CFormLabel>
                              <br></br>
                              <CFormLabel htmlFor="inputText4">{singleItem?.C_CompanyAddres}</CFormLabel>

                            </CCol>
                            <CCol md={6}>
                              <CFormLabel htmlFor="inputText4">Job Title</CFormLabel>
                              <br></br>
                              <CFormLabel htmlFor="inputText4">{singleItem?.C_JobTitle}</CFormLabel>

                            </CCol>
                            <CCol md={6}>
                              <CFormLabel htmlFor="inputText4">Department</CFormLabel>
                              <br></br>
                              <CFormLabel htmlFor="inputText4">{singleItem?.C_Department}</CFormLabel>

                            </CCol>
                            <CCol md={6}>
                              <CFormLabel htmlFor="inputText4">Employement Since</CFormLabel>
                              <br></br>
                              <CFormLabel htmlFor="inputText4">{singleItem?.C_EmployementSince}</CFormLabel>

                            </CCol>
                            <CCol md={6}>
                              <CFormLabel htmlFor="inputText4">Employement Number</CFormLabel>
                              <br></br>
                              <CFormLabel htmlFor="inputText4">{singleItem?.C_EmploymentNumber}</CFormLabel>

                            </CCol>
                            <CCol md={6}>
                              <CFormLabel htmlFor="inputText4">Extension</CFormLabel>
                              <br></br>
                              <CFormLabel htmlFor="inputText4">{singleItem?.C_Extension}</CFormLabel>

                            </CCol>
                            <CCol md={6}>
                              <CFormLabel htmlFor="inputText4">Office Email</CFormLabel>
                              <br></br>
                              <CFormLabel htmlFor="inputText4">{singleItem?.C_OfficeEmail}</CFormLabel>

                            </CCol>
                            <CCol md={6}>
                              <CFormLabel htmlFor="inputState">Employement Type</CFormLabel>
                              <br></br>
                              <CFormLabel htmlFor="inputText4">{singleItem?.C_EmployementType}</CFormLabel>

                            </CCol>

                            <h1>Previous Employement Details</h1>
                            <CCol md={6}>
                              <CFormLabel htmlFor="inputText4">Company Name</CFormLabel>
                              <br></br>
                              <CFormLabel htmlFor="inputText4">{singleItem?.P_CompnayName}</CFormLabel>

                            </CCol>
                            <CCol md={6}>
                              <CFormLabel htmlFor="inputText4">Company Address</CFormLabel>
                              <br></br>
                              <CFormLabel htmlFor="inputText4">{singleItem?.P_CompanyAddres}</CFormLabel>

                            </CCol>
                            <CCol md={6}>
                              <CFormLabel htmlFor="inputText4">Job Title</CFormLabel>
                              <br></br>
                              <CFormLabel htmlFor="inputText4">{singleItem?.P_JobTitle}</CFormLabel>

                            </CCol>
                            <CCol md={6}>
                              <CFormLabel htmlFor="inputText4">Department</CFormLabel>
                              <br></br>
                              <CFormLabel htmlFor="inputText4">{singleItem?.P_Department}</CFormLabel>

                            </CCol>
                            <CCol md={6}>
                              <CFormLabel htmlFor="inputText4">Employement Period</CFormLabel>
                              <br></br>
                              <CFormLabel htmlFor="inputText4">From</CFormLabel>
                              <br></br>
                              <CFormLabel htmlFor="inputText4">{singleItem?.P_EmployementSince}</CFormLabel>

                            </CCol>
                            <CCol md={6}>
                              <CFormLabel htmlFor="inputText4">Employement Period</CFormLabel>
                              <br></br>
                              <CFormLabel htmlFor="inputText4">To</CFormLabel>
                              <br></br>
                              <CFormLabel htmlFor="inputText4">{singleItem?.P_EmployementSinceT}</CFormLabel>

                            </CCol>
                            <CCol md={6}>
                              <CFormLabel htmlFor="inputText4">Employement Number</CFormLabel>
                              <br></br>
                              <CFormLabel htmlFor="inputText4">{singleItem?.P_EmploymentNumber}</CFormLabel>

                            </CCol>
                            <CCol md={6}>
                              <CFormLabel htmlFor="inputText4">Extension</CFormLabel>
                              <br></br>
                              <CFormLabel htmlFor="inputText4">{singleItem?.P_Extension}</CFormLabel>

                            </CCol>
                            <CCol md={6}>
                              <CFormLabel htmlFor="inputText4">Office Email</CFormLabel>
                              <br></br>
                              <CFormLabel htmlFor="inputText4">{singleItem?.P_OfficeEmail}</CFormLabel>

                            </CCol>
                            <CCol md={6}>
                              <CFormLabel htmlFor="inputState">Employement Type</CFormLabel>
                              <br></br>
                              <CFormLabel htmlFor="inputText4">{singleItem?.P_EmployementType}</CFormLabel>

                            </CCol>
                          </CForm>
                        </DocsExample>
                      </CCardBody>
                    </CCard>
                  </CCol>
                </CRow>
                <CRow className='justify-content-center'>
                  <CCol md={5}>
                    <CCard className="mb-6">
                      <CCardBody>
                        <DocsExample>
                          <CForm className="row g-3">
                            <h1>Business Details </h1>
                            <h4>*If Your Income Is From Business*</h4>
                            <CCol md={6}>
                              <CFormLabel htmlFor="inputText4">Number Of Business</CFormLabel>
                              <br></br>
                              <CFormLabel htmlFor="inputText4">{singleItem?.numberOfBusiness}</CFormLabel>

                            </CCol>
                            <CCol md={6}>
                              <CFormLabel htmlFor="inputText4">Business Title</CFormLabel>
                              <br></br>
                              <CFormLabel htmlFor="inputText4">{singleItem?.businessTitle}</CFormLabel>

                            </CCol>
                            <CCol xs={12}>
                              <CFormLabel htmlFor="inputText4">Business Address</CFormLabel>
                              <br></br>
                              <CFormLabel htmlFor="inputText4">{singleItem?.businessAddress}</CFormLabel>

                            </CCol>
                            <CCol md={6}>
                              <CFormLabel htmlFor="inputText4">Business Type</CFormLabel>
                              <br></br>
                              <CFormLabel htmlFor="inputText4">{singleItem?.businessType}</CFormLabel>

                            </CCol>
                            <CCol md={6}>
                              <CFormLabel htmlFor="inputText4">Industry Type</CFormLabel>
                              <br></br>
                              <CFormLabel htmlFor="inputText4">{singleItem?.industryType}</CFormLabel>

                            </CCol>
                            <CCol md={6}>
                              <CFormLabel htmlFor="inputText4">Business's NTN Number</CFormLabel>
                              <br></br>
                              <CFormLabel htmlFor="inputText4">{singleItem?.ntnNumber}</CFormLabel>

                            </CCol>
                            <CCol md={6}>
                              <CFormLabel htmlFor="inputText4">Established Since</CFormLabel>
                              <br></br>
                              <CFormLabel htmlFor="inputText4">{singleItem?.establishedSince}</CFormLabel>

                            </CCol>
                            <CCol md={6}>
                              <CFormLabel htmlFor="inputText4">Register With</CFormLabel>
                              <br></br>
                              <CFormLabel htmlFor="inputText4">{singleItem?.registerWith}</CFormLabel>

                            </CCol>
                            <CCol md={6}>
                              <CFormLabel htmlFor="inputText4">Business Telephone Number</CFormLabel>
                              <br></br>
                              <CFormLabel htmlFor="inputText4">{singleItem?.businessTelephoneNumber}</CFormLabel>

                            </CCol>
                            <CCol md={6}>
                              <CFormLabel htmlFor="inputText4">Business Email</CFormLabel>
                              <br></br>
                              <br></br>

                              <br></br>
                              <CFormLabel htmlFor="inputText4">{singleItem?.businessEmail}</CFormLabel>

                            </CCol>
                            <CCol md={6}>
                              <CFormLabel htmlFor="inputText4">Self Employed Professionals (SEP):</CFormLabel>
                              <br></br>
                              <CFormLabel htmlFor="inputText4">Name Of Company</CFormLabel>
                              <br></br>
                              <CFormLabel htmlFor="inputText4">{singleItem?.companyName}</CFormLabel>

                            </CCol>

                            <CCol md={6}>
                              <CFormLabel htmlFor="inputState">Type Of Business</CFormLabel>
                              <br></br>
                              <CFormLabel htmlFor="inputText4">{singleItem?.typeOfBusiness}</CFormLabel>

                            </CCol>

                            <CCol md={6}>
                              <CFormLabel htmlFor="inputState">Professional Qualifications</CFormLabel>
                              <br></br>
                              <CFormLabel htmlFor="inputText4">{singleItem?.professionalQualifications}</CFormLabel>

                              <br></br>
                              <br></br>
                              <CFormLabel htmlFor="inputText4">{singleItem?.s_specify_professionalQualifications}</CFormLabel>

                            </CCol>
                          </CForm>
                        </DocsExample>
                      </CCardBody>
                    </CCard>
                  </CCol>
                </CRow>
                <CRow className='justify-content-center'>
                  <CCol md={5}>
                    <CCard className="mb-6">
                      <CCardBody>
                        <DocsExample href="forms/layout#gutters">
                          <CForm className="row g-3">
                            <h1>Income Details</h1>
                            <CCol md={6}>
                              <CFormLabel htmlFor="inputText4">Monthly Gross Income</CFormLabel>
                              <br></br>
                              <CFormLabel htmlFor="inputText4">{singleItem?.MonthlyGrossIncome}</CFormLabel>

                            </CCol>
                            <CCol md={6}>
                              <CFormLabel htmlFor="inputText4">Monthly Net Income</CFormLabel>
                              <br></br>
                              <CFormLabel htmlFor="inputText4">{singleItem?.MonthlyNetIncome}</CFormLabel>

                            </CCol>

                            <CCol md={6}>
                              <CFormLabel htmlFor="inputText4">Salaray Disbursement Day</CFormLabel>
                              <br></br>
                              <CFormLabel htmlFor="inputText4">{singleItem?.SalarayDisbursementDay}</CFormLabel>

                            </CCol>
                            <CCol md={6}>
                              <CFormLabel htmlFor="inputText4">
                                Other Verifiable Income (if any) For SEP's Only
                              </CFormLabel>
                              <br></br>
                              <CFormLabel htmlFor="inputText4">{singleItem?.OtherVerIncome}</CFormLabel>

                            </CCol>
                            <CCol md={6}>
                              <CFormLabel htmlFor="inputText4">Source Of Other Income</CFormLabel>
                              <br></br>
                              <CFormLabel htmlFor="inputText4">{singleItem?.SourceOfOtherIncome}</CFormLabel>

                            </CCol>
                            <CCol md={6}>
                              <CFormLabel htmlFor="inputText4">Average Monthly Income</CFormLabel>
                              <br></br>
                              <CFormLabel htmlFor="inputText4">{singleItem?.AverageMonthlyIncome}</CFormLabel>

                            </CCol>

                            <h1>Banking Details</h1>

                            <CCol md={6}>
                              <CFormLabel htmlFor="inputText4">Bank Name</CFormLabel>
                              <br></br>
                              <CFormLabel htmlFor="inputText4">{singleItem?.BankName}</CFormLabel>

                            </CCol>
                            <CCol md={6}>
                              <CFormLabel htmlFor="inputText4">Account Number</CFormLabel>
                              <br></br>
                              <CFormLabel htmlFor="inputText4">{singleItem?.AccountNumber}</CFormLabel>

                            </CCol>

                            <CCol md={6}>
                              <CFormLabel htmlFor="inputState">Account Type</CFormLabel>
                              <br></br>
                              <CFormLabel htmlFor="inputText4">{singleItem?.AccountType}</CFormLabel>

                            </CCol>
                            <CCol md={6}>
                              <CFormLabel htmlFor="inputText4">Bank Branch</CFormLabel>
                              <br></br>
                              <CFormLabel htmlFor="inputText4">{singleItem?.Branch}</CFormLabel>

                            </CCol>

                            <h1>Desired Financing</h1>

                            <CCol mb={3}>
                              <CFormLabel htmlFor="inputText4">Ammount Sought PKR</CFormLabel>
                              <br></br>
                              <CFormLabel htmlFor="inputText4">{singleItem?.AmmountSoughtPKR}</CFormLabel>

                            </CCol>

                            <CCol md={6}>
                              <CFormLabel htmlFor="inputState">Desired Repayment Tenure</CFormLabel>
                              <br></br>
                              <CFormLabel htmlFor="inputText4">{singleItem?.DesiredRepTenure}</CFormLabel>

                            </CCol>

                            <CCol md={6}>
                              <CFormLabel htmlFor="inputState">Loan Required For</CFormLabel>
                              <br></br>
                              <CFormLabel htmlFor="inputText4">{singleItem?.LoanReqFor}</CFormLabel>

                            </CCol>
                          </CForm>
                        </DocsExample>
                      </CCardBody>
                    </CCard>
                  </CCol>
                </CRow>
                <CRow className='justify-content-center'>
                  <CCol md={5}>
                    <CCard className="mb-6">
                      <CCardBody>
                        <DocsExample href="forms/layout#gutters">
                          <CForm className="row g-3">
                            <h1>Details Of References</h1>
                            <h3>Reference 01</h3>
                            <CCol md={6}>
                              <CFormLabel htmlFor="inputText4">Full Name</CFormLabel>
                              <br></br>
                              <CFormLabel htmlFor="inputText4">{singleItem?.R_FullName}</CFormLabel>

                            </CCol>
                            <CCol md={6}>
                              <CFormLabel htmlFor="inputText4">CNIC</CFormLabel>
                              <br></br>
                              <CFormLabel htmlFor="inputText4">{singleItem?.R_CINC}</CFormLabel>

                            </CCol>
                            <CCol md={6}>
                              <CFormLabel htmlFor="inputText4">Passport Number</CFormLabel>
                              <br></br>
                              <CFormLabel htmlFor="inputText4">{singleItem?.R_PossportNumber}</CFormLabel>

                            </CCol>
                            <CCol md={6}>
                              <CFormLabel htmlFor="inputText4">Address</CFormLabel>
                              <br></br>
                              <CFormLabel htmlFor="inputText4">{singleItem?.R_Address}</CFormLabel>

                            </CCol>
                            <CCol md={6}>
                              <CFormLabel htmlFor="inputText4">Telephone Number Office</CFormLabel>
                              <br></br>
                              <CFormLabel htmlFor="inputText4">{singleItem?.R_TelephoneNumOffice}</CFormLabel>

                            </CCol>
                            <CCol md={6}>
                              <CFormLabel htmlFor="inputText4">Telephone Number Residence</CFormLabel>
                              <br></br>
                              <CFormLabel htmlFor="inputText4">{singleItem?.R_TelephoneNumResidence}</CFormLabel>

                            </CCol>

                            <CCol md={6}>
                              <CFormLabel htmlFor="inputText4">Email</CFormLabel>
                              <br></br>
                              <CFormLabel htmlFor="inputText4">{singleItem?.R_Email}</CFormLabel>

                            </CCol>

                            <CCol md={6}>
                              <CFormLabel htmlFor="inputText4">Cell Number</CFormLabel>
                              <br></br>
                              <CFormLabel htmlFor="inputText4">{singleItem?.R_CellNumber}</CFormLabel>

                            </CCol>
                            <CCol md={6}>
                              <CFormLabel htmlFor="inputText4">Relationship</CFormLabel>
                              <br></br>
                              <CFormLabel htmlFor="inputText4">{singleItem?.R_Relationship}</CFormLabel>

                            </CCol>

                            <h3>Reference 02</h3>
                            <CCol md={6}>
                              <CFormLabel htmlFor="inputText4">Full Name</CFormLabel>
                              <br></br>
                              <CFormLabel htmlFor="inputText4">{singleItem?.R2_FullName}</CFormLabel>

                            </CCol>
                            <CCol md={6}>
                              <CFormLabel htmlFor="inputText4">CNIC</CFormLabel>
                              <br></br>
                              <CFormLabel htmlFor="inputText4">{singleItem?.R2_CINC}</CFormLabel>

                            </CCol>
                            <CCol md={6}>
                              <CFormLabel htmlFor="inputText4">Passport Number</CFormLabel>
                              <br></br>
                              <CFormLabel htmlFor="inputText4">{singleItem?.R2_PossportNumber}</CFormLabel>

                            </CCol>
                            <CCol md={6}>
                              <CFormLabel htmlFor="inputText4">Address</CFormLabel>
                              <br></br>
                              <CFormLabel htmlFor="inputText4">{singleItem?.R2_Address}</CFormLabel>

                            </CCol>
                            <CCol md={6}>
                              <CFormLabel htmlFor="inputText4">Telephone Number Office</CFormLabel>
                              <br></br>
                              <CFormLabel htmlFor="inputText4">{singleItem?.R2_TelephoneNumOffice}</CFormLabel>

                            </CCol>
                            <CCol md={6}>
                              <CFormLabel htmlFor="inputText4">Telephone Number Residencec</CFormLabel>
                              <br></br>
                              <CFormLabel htmlFor="inputText4">{singleItem?.R2_TelephoneNumResidence}</CFormLabel>

                            </CCol>

                            <CCol md={6}>
                              <CFormLabel htmlFor="inputText4">Email</CFormLabel>
                              <br></br>
                              <CFormLabel htmlFor="inputText4">{singleItem?.R2_Email}</CFormLabel>

                            </CCol>

                            <CCol md={6}>
                              <CFormLabel htmlFor="inputText4">Cell Number</CFormLabel>
                              <br></br>
                              <CFormLabel htmlFor="inputText4">{singleItem?.R2_CellNumber}</CFormLabel>

                            </CCol>
                            <CCol md={6}>
                              <CFormLabel htmlFor="inputText4">Relationship</CFormLabel>
                              <br></br>
                              <CFormLabel htmlFor="inputText4">{singleItem?.R2_Relationship}</CFormLabel>

                            </CCol>
                          </CForm>
                        </DocsExample>
                      </CCardBody>
                    </CCard>

                  </CCol>
                </CRow>
              </div>
        

          </div>
        </CModalBody>
        <CModalFooter>
          <CButton color="secondary" onClick={() => setVisible(false)}>
            Close
          </CButton>
        </CModalFooter>
      </CModal>




    </>
  )
}

export default Application;