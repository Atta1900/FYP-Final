import React from 'react';


const Hellow = () => {
    return (
        <div className='stepIndicator'>
            <div className='stepIndicator'>Submitted</div>
            <div className='stepIndicator'>Verification</div>
            <div className='stepIndicator'>Approved</div>
            <div className='stepIndicator'>Disbursed</div>

        </div>

    )
}

export default Hellow
