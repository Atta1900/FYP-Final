import React from 'react'
import {
  CButton,
  CCard,
  CCardBody,
  CCol,
  CForm,
  CFormInput,
  CFormLabel,
  CFormSelect,
  CRow,
} from '@coreui/react'
import { DocsExample } from 'src/components'

const ContactInfo = () => {
  return (
    <CRow>
      <CCol>
        <CCard className="mb-4">
          <CCardBody>
            <DocsExample href="forms/layout#gutters">
              <CForm className="row g-3">
                <h1>Contact Info</h1>
                <CCol xs={12}>
                  <CFormLabel htmlFor="inputText4">Address</CFormLabel>
                  <CFormInput id="inputAddress" label="Address" />
                </CCol>
                <CCol md={6}>
                  <CFormLabel htmlFor="inputText4">Postal Code</CFormLabel>
                  <CFormInput type="Text" id="inputText4" />
                </CCol>
                <CCol md={6}>
                  <CFormLabel htmlFor="inputText4">City</CFormLabel>
                  <CFormInput type="Text" id="inputText4" />
                </CCol>

                <CCol md={6}>
                  <CFormLabel htmlFor="inputText4">Mobile Number</CFormLabel>
                  <CFormInput type="Text" id="inputText4" />
                </CCol>
                <CCol md={6}>
                  <CFormLabel htmlFor="inputText4">Email</CFormLabel>
                  <CFormInput type="Text" id="inputText4" />
                </CCol>
                <CCol md={6}>
                  <CFormLabel htmlFor="inputState">Resident Type</CFormLabel>
                  <CFormSelect id="inputState">
                    <option>Select</option>
                    <option>Owned</option>
                    <option>Rented</option>
                    <option>Company</option>
                    <option>PArents</option>
                    <option>Financed/Leased</option>
                  </CFormSelect>
                </CCol>
                <CCol md={6}>
                  <CFormLabel htmlFor="inputState">Accomodation Type</CFormLabel>
                  <CFormSelect id="inputState">
                    <option>Select</option>
                    <option>House</option>
                    <option>Appartment</option>
                    <option>Portion</option>
                    <option>Room</option>
                  </CFormSelect>
                </CCol>

                <CCol md={6}>
                  <CFormLabel htmlFor="inputText4">Monthly Rent (If Rented)</CFormLabel>
                  <CFormInput type="Text" id="inputText4" />
                </CCol>
                <CCol md={6}>
                  <CFormLabel htmlFor="inputText4">Installment Amount (If Motgage)</CFormLabel>
                  <CFormInput type="Text" id="inputText4" />
                </CCol>

                <CCol xs={12}>
                  <CFormLabel htmlFor="inputText4">Permanent Address</CFormLabel>
                  <CFormInput id="inputAddress" label="Address" />
                </CCol>
                <CCol md={6}>
                  <CFormLabel htmlFor="inputText4">Postal Code</CFormLabel>
                  <CFormInput type="Text" id="inputText4" />
                </CCol>
                <CCol md={6}>
                  <CFormLabel htmlFor="inputText4">City</CFormLabel>
                  <CFormInput type="Text" id="inputText4" />
                </CCol>

                <CCol md={6}>
                  <CFormLabel htmlFor="inputState">Resident Type</CFormLabel>
                  <CFormSelect id="inputState">
                    <option>Select</option>
                    <option>Owned</option>
                    <option>Rented</option>
                    <option>Company</option>
                    <option>Parents</option>
                    <option>Financed/Leased</option>
                  </CFormSelect>
                </CCol>

                <CCol mb={3}>
                  <CFormLabel htmlFor="inputText4">Number Of Cars</CFormLabel>
                  <CFormInput type="Text" id="inputText4" />
                </CCol>

                <CCol md={6}>
                  <CFormLabel htmlFor="inputText4">Make & Model</CFormLabel>
                  <CFormInput type="Text" id="inputText4" />
                </CCol>

                <CCol>
                  <CButton type="submit">Prev Page</CButton>
                  <CButton type="submit">Next Page</CButton>
                </CCol>
              </CForm>
            </DocsExample>
          </CCardBody>
        </CCard>
      </CCol>
    </CRow>
  )
}
export default ContactInfo
