import React from 'react'

import {
  CButton,
  CCard,
  CCardBody,
  CCol,
  CForm,
  CFormInput,
  CFormLabel,
  CFormSelect,
  CRow,
} from '@coreui/react'

import { DocsExample } from 'src/components'

const BusinessDetails = () => {
  return (
    <CRow>
      <CCol>
        <CCard className="mb-4">
          <CCardBody>
            <DocsExample href="forms/layout#gutters">
              <CForm className="row g-3">
                <h1>Business Details (If Your Income Is From Business)</h1>
                <CCol md={6}>
                  <CFormLabel htmlFor="inputText4">Number Of Business</CFormLabel>
                  <CFormInput type="Text" id="inputText4" />
                </CCol>
                <CCol md={6}>
                  <CFormLabel htmlFor="inputText4">Business Title</CFormLabel>
                  <CFormInput type="Text" id="inputText4" />
                </CCol>
                <CCol xs={12}>
                  <CFormLabel htmlFor="inputText4">Business Address</CFormLabel>
                  <CFormInput id="inputAddress" label="Address" />
                </CCol>
                <CCol md={6}>
                  <CFormLabel htmlFor="inputText4">Business Type</CFormLabel>
                  <CFormInput type="Text" id="inputText4" />
                </CCol>
                <CCol md={6}>
                  <CFormLabel htmlFor="inputText4">Industry Type</CFormLabel>
                  <CFormInput type="Text" id="inputText4" />
                </CCol>
                <CCol md={6}>
                  <CFormLabel htmlFor="inputText4">Business's NTN Number</CFormLabel>
                  <CFormInput type="Text" id="inputText4" />
                </CCol>
                <CCol md={6}>
                  <CFormLabel htmlFor="inputText4">Established Since</CFormLabel>
                  <CFormInput type="date" id="inputText4" />
                </CCol>
                <CCol md={6}>
                  <CFormLabel htmlFor="inputText4">Register With</CFormLabel>
                  <CFormInput type="Text" id="inputText4" />
                </CCol>
                <CCol md={6}>
                  <CFormLabel htmlFor="inputText4">Business Telephone Number</CFormLabel>
                  <CFormInput type="Text" id="inputText4" />
                </CCol>
                <CCol md={6}>
                  <CFormLabel htmlFor="inputText4">Business Email</CFormLabel>
                  <br></br>
                  <br></br>

                  <CFormInput type="Text" id="inputText4" />
                </CCol>
                <CCol md={6}>
                  <CFormLabel htmlFor="inputText4">Self Employed Professionals (SEP):</CFormLabel>
                  <br></br>
                  <CFormLabel htmlFor="inputText4">Name Of Company</CFormLabel>
                  <CFormInput type="Text" id="inputText4" />
                </CCol>

                <CCol md={6}>
                  <CFormLabel htmlFor="inputState">Type Of Business</CFormLabel>
                  <CFormSelect id="inputState">
                    <option>Select</option>
                    <option>Sole Proprietorship</option>
                    <option>Patnership</option>
                    <option>Other</option>
                  </CFormSelect>
                  <br></br>
                  <CFormInput type="text" id="inputText4" placeholder="Please Specify" />
                </CCol>

                <CCol md={6}>
                  <CFormLabel htmlFor="inputState">Professional Qualifications</CFormLabel>
                  <CFormSelect id="inputState">
                    <option>Select</option>
                    <option>Chartered Accountant</option>
                    <option>Doctor</option>
                    <option>Engineer</option>
                    <option>Architect</option>
                    <option>Other</option>
                  </CFormSelect>
                  <br></br>

                  <CFormInput type="text" id="inputText4" placeholder="Please Specify" />
                </CCol>

                <CCol mb={3}>
                  <CButton type="submit">Prev Page</CButton>
                  <CButton type="submit">Next Page</CButton>
                </CCol>
              </CForm>
            </DocsExample>
          </CCardBody>
        </CCard>
      </CCol>
    </CRow>
  )
}
export default BusinessDetails
