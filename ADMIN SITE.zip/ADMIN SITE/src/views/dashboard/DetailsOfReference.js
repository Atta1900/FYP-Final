import React from 'react'
import { CButton, CCard, CCardBody, CCol, CForm, CFormInput, CFormLabel, CRow } from '@coreui/react'
import { DocsExample } from 'src/components'

const DetailsOfReferences = () => {
  return (
    <CRow>
      <CCol>
        <CCard className="mb-4">
          <CCardBody>
            <p className="Text-medium-emphasis small">Application Form</p>
            <DocsExample href="forms/layout#gutters">
              <CForm className="row g-3">
                <h1>Details Of References</h1>
                <h3>Reference 01</h3>
                <CCol md={6}>
                  <CFormLabel htmlFor="inputText4">Full Name</CFormLabel>
                  <CFormInput type="Text" id="inputText4" />
                </CCol>
                <CCol md={6}>
                  <CFormLabel htmlFor="inputText4">CNIC</CFormLabel>
                  <CFormInput type="Text" id="inputText4" />
                </CCol>
                <CCol md={6}>
                  <CFormLabel htmlFor="inputText4">Passport Number</CFormLabel>
                  <CFormInput type="number" id="inputText4" />
                </CCol>
                <CCol md={6}>
                  <CFormLabel htmlFor="inputText4">Address</CFormLabel>
                  <CFormInput type="Text" id="inputText4" />
                </CCol>
                <CCol md={6}>
                  <CFormLabel htmlFor="inputText4">Telephone Number Office</CFormLabel>
                  <CFormInput type="Text" id="inputText4" />
                </CCol>
                <CCol md={6}>
                  <CFormLabel htmlFor="inputText4">Telephone Number Residencec</CFormLabel>
                  <CFormInput type="Text" id="inputText4" />
                </CCol>

                <CCol md={6}>
                  <CFormLabel htmlFor="inputText4">Email</CFormLabel>
                  <CFormInput type="Text" id="inputText4" />
                </CCol>

                <CCol md={6}>
                  <CFormLabel htmlFor="inputText4">Cell Number</CFormLabel>
                  <CFormInput type="Text" id="inputText4" />
                </CCol>
                <CCol md={6}>
                  <CFormLabel htmlFor="inputText4">Relationsip</CFormLabel>
                  <CFormInput type="Text" id="inputText4" />
                </CCol>

                <h3>Reference 02</h3>
                <CCol md={6}>
                  <CFormLabel htmlFor="inputText4">Full Name</CFormLabel>
                  <CFormInput type="Text" id="inputText4" />
                </CCol>
                <CCol md={6}>
                  <CFormLabel htmlFor="inputText4">CNIC</CFormLabel>
                  <CFormInput type="Text" id="inputText4" />
                </CCol>
                <CCol md={6}>
                  <CFormLabel htmlFor="inputText4">Passport Number</CFormLabel>
                  <CFormInput type="number" id="inputText4" />
                </CCol>
                <CCol md={6}>
                  <CFormLabel htmlFor="inputText4">Address</CFormLabel>
                  <CFormInput type="Text" id="inputText4" />
                </CCol>
                <CCol md={6}>
                  <CFormLabel htmlFor="inputText4">Telephone Number Office</CFormLabel>
                  <CFormInput type="Text" id="inputText4" />
                </CCol>
                <CCol md={6}>
                  <CFormLabel htmlFor="inputText4">Telephone Number Residencec</CFormLabel>
                  <CFormInput type="Text" id="inputText4" />
                </CCol>

                <CCol md={6}>
                  <CFormLabel htmlFor="inputText4">Email</CFormLabel>
                  <CFormInput type="Text" id="inputText4" />
                </CCol>

                <CCol md={6}>
                  <CFormLabel htmlFor="inputText4">Cell Number</CFormLabel>
                  <CFormInput type="Text" id="inputText4" />
                </CCol>
                <CCol md={6}>
                  <CFormLabel htmlFor="inputText4">Relationsip</CFormLabel>
                  <CFormInput type="Text" id="inputText4" />
                </CCol>
                <CCol mb={3}>
                  <CButton type="submit">Prev Page</CButton>
                  <CButton type="submit">Submit</CButton>
                </CCol>
              </CForm>
            </DocsExample>
          </CCardBody>
        </CCard>
      </CCol>
    </CRow>
  )
}
export default DetailsOfReferences
