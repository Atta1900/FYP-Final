import React from 'react'
import {
  CButton,
  CCard,
  CCardBody,
  CCol,
  CForm,
  CFormInput,
  CFormLabel,
  CFormSelect,
  CRow,
} from '@coreui/react'
import { DocsExample } from 'src/components'

const EmployementDetail = () => {
  return (
    <CRow>
      <CCol>
        <CCard className="mb-4">
          <CCardBody>
            <DocsExample href="forms/layout#gutters">
              <CForm className="row g-3">
                <h1>Employement Details (For Salaried Indivisual Only)</h1>
                <CCol md={6}>
                  <CFormLabel htmlFor="inputText4">Company Name</CFormLabel>
                  <CFormInput type="Text" id="inputText4" />
                </CCol>
                <CCol md={6}>
                  <CFormLabel htmlFor="inputText4">Company Address</CFormLabel>
                  <CFormInput type="Text" id="inputText4" />
                </CCol>
                <CCol md={6}>
                  <CFormLabel htmlFor="inputText4">Job Title</CFormLabel>
                  <CFormInput type="Text" id="inputText4" />
                </CCol>
                <CCol md={6}>
                  <CFormLabel htmlFor="inputText4">Department</CFormLabel>
                  <CFormInput type="Text" id="inputText4" />
                </CCol>
                <CCol md={6}>
                  <CFormLabel htmlFor="inputText4">Employement Since</CFormLabel>
                  <CFormInput type="date" id="inputText4" />
                </CCol>
                <CCol md={6}>
                  <CFormLabel htmlFor="inputText4">Employement Number</CFormLabel>
                  <CFormInput type="Text" id="inputText4" />
                </CCol>
                <CCol md={6}>
                  <CFormLabel htmlFor="inputText4">Extension</CFormLabel>
                  <CFormInput type="Text" id="inputText4" />
                </CCol>
                <CCol md={6}>
                  <CFormLabel htmlFor="inputText4">Office Email</CFormLabel>
                  <CFormInput type="Text" id="inputText4" />
                </CCol>
                <CCol md={6}>
                  <CFormLabel htmlFor="inputState">Professional Qualifications</CFormLabel>
                  <CFormSelect id="inputState">
                    <option>Select</option>
                    <option>Permanent</option>
                    <option>Contractual</option>
                  </CFormSelect>
                </CCol>

                <h1>Previous Employement Details</h1>
                <CCol md={6}>
                  <CFormLabel htmlFor="inputText4">Company Name</CFormLabel>
                  <CFormInput type="Text" id="inputText4" />
                </CCol>
                <CCol md={6}>
                  <CFormLabel htmlFor="inputText4">Company Address</CFormLabel>
                  <CFormInput type="Text" id="inputText4" />
                </CCol>
                <CCol md={6}>
                  <CFormLabel htmlFor="inputText4">Job Title</CFormLabel>
                  <CFormInput type="Text" id="inputText4" />
                </CCol>
                <CCol md={6}>
                  <CFormLabel htmlFor="inputText4">Department</CFormLabel>
                  <CFormInput type="Text" id="inputText4" />
                </CCol>
                <CCol md={6}>
                  <CFormLabel htmlFor="inputText4">Employement Period</CFormLabel>
                  <br></br>
                  <CFormLabel htmlFor="inputText4">From</CFormLabel>
                  <CFormInput type="date" id="inputText4" />
                </CCol>
                <CCol md={6}>
                  <CFormLabel htmlFor="inputText4">Employement Period</CFormLabel>
                  <br></br>
                  <CFormLabel htmlFor="inputText4">To</CFormLabel>
                  <CFormInput type="date" id="inputText4" />
                </CCol>
                <CCol md={6}>
                  <CFormLabel htmlFor="inputText4">Employement Number</CFormLabel>
                  <CFormInput type="Text" id="inputText4" />
                </CCol>
                <CCol md={6}>
                  <CFormLabel htmlFor="inputText4">Extension</CFormLabel>
                  <CFormInput type="Text" id="inputText4" />
                </CCol>
                <CCol md={6}>
                  <CFormLabel htmlFor="inputText4">Office Email</CFormLabel>
                  <CFormInput type="Text" id="inputText4" />
                </CCol>
                <CCol md={6}>
                  <CFormLabel htmlFor="inputState">Professional Qualifications</CFormLabel>
                  <CFormSelect id="inputState">
                    <option>Select</option>
                    <option>Permanent</option>
                    <option>Contractual</option>
                  </CFormSelect>
                </CCol>
                <CCol mb={3}>
                  <CButton type="submit">Prev Page</CButton>
                  <CButton type="submit">Next Page</CButton>
                </CCol>
              </CForm>
            </DocsExample>
          </CCardBody>
        </CCard>
      </CCol>
    </CRow>
  )
}
export default EmployementDetail
