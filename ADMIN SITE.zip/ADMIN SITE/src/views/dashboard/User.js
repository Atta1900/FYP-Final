import React from 'react'
import {
    CCard,
    CCardBody,
    CCardHeader,
    CCardImage,
    CCol,
    CRow,
} from '@coreui/react'
import { DocsExample } from 'src/components'
import ReactImg from 'src/assets/images/4.jpeg'


const User = () => {
    return (

        <CRow>
            <CCol xs={12}>
                <CCard className="mb-4">
                    <CCardHeader>
                        <strong>Hi User</strong>
                    </CCardHeader>
                    <CCardBody>
                        <DocsExample href="components/placeholder">
                            <div className="d-flex justify-content-around p-3" >
                                <CCard style={{ width: '22rem', height: '25%' }}>
                                    <CCardImage orientation="top" src={ReactImg} />
                                </CCard>
                                <CCard style={{ width: '78rem', height: '100pxs' }}>
                                    <CCardBody>
                                        <br></br>
                                        <hr></hr>
                                        <br></br>
                                        <hr></hr>
                                    </CCardBody>
                                </CCard>
                            </div>
                        </DocsExample>
                    </CCardBody>
                </CCard>
            </CCol>
        </CRow>
    )
}
export default User