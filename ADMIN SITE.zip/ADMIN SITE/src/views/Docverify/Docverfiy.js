import React, { useState, useEffect } from 'react'
import axios from 'axios'
import { useNavigate } from "react-router-dom";

import {
    CButton,
    CCard,
    CCardBody,
    CAvatar,
    CCol,
    CRow,
    CTable,
    CTableBody,
    CTableDataCell,
    CTableHead,
    CTableHeaderCell,
    CTableRow,
    CModal,
    CModalBody,
    CModalHeader,
    CModalTitle,
    CModalFooter,
} from '@coreui/react'
import CIcon from '@coreui/icons-react'
import {
    cilPeople,
} from '@coreui/icons'
import ViewDoc from 'src/components/ViewDoc'


const Docverify = () => {
    const [visible, setVisible] = useState(false)

    const nav = useNavigate()
    const random = (min, max) => Math.floor(Math.random() * (max - min + 1) + min)
    const [myData, setmyData] = useState([]);
    const [singleData, setSingleData] = useState(null)
    const allData = () => {

        axios({
            method: 'GET',
            url: "http://127.0.0.1:8000/api/ApplicationForm"
        })
            .then((response) => {
                var data = response.data;
                var newdata = data.filter((e) => {
                    return e.Status != "approaved"
                })
                setmyData(newdata)
                console.log(data)

            }, (error) => {
                console.log(error);

            });
    }
    useEffect(() => {
        allData();
    }, myData.length)

    const updateStatus = async (id, status, item = null) => {
        var formdata = new FormData();
        formdata.append("status", status);

        axios({
            method: 'PUT',
            url: `http://localhost:8000/api/UpdateStuatus/${id}`,
            data: formdata,

        })
            .then((response) => {
                var data = response.data;
                console.log(data)
                allData();

            }, (error) => {
                console.log(error);

            });
        if (status == "verification") {
            setVisible(true)
            setSingleData(item)

        }
    }
    return (
        <>
            <h1>Pending Applications</h1>
            <CRow>
                <CCol xs>
                    <CCard className="mb-4">

                        <CCardBody>
                            <CTable align="middle" className="mb-0 border" hover responsive>
                                <CTableHead color="light">
                                    <CTableRow>
                                        <CTableHeaderCell className="text-center">
                                            <CIcon icon={cilPeople} />
                                        </CTableHeaderCell>
                                        <CTableHeaderCell >Application No.</CTableHeaderCell>
                                        <CTableHeaderCell className="text-center">Name</CTableHeaderCell>
                                        <CTableHeaderCell>Loan Amount</CTableHeaderCell>
                                        <CTableHeaderCell className="text-center">Applied Date</CTableHeaderCell>
                                        <CTableHeaderCell className="text-center">Status</CTableHeaderCell>
                                        <CTableHeaderCell>Action Required After Manual Verification</CTableHeaderCell>
                                    </CTableRow>
                                </CTableHead>
                                <CTableBody>
                                    {myData.map((item, index) => (
                                        <CTableRow v-for="item in tableItems" key={index}>
                                            <CTableDataCell className="text-center">
                                                <CAvatar size="md" src={`http://127.0.0.1:8000${item.profilePicFile}`} />

                                            </CTableDataCell>
                                            <CTableDataCell className="text-center">
                                                <div>{item.applicationID}</div>
                                            </CTableDataCell>
                                            <CTableDataCell className="text-center">
                                                <div>{item.FirstName} {item.LastName}</div>
                                            </CTableDataCell>
                                            <CTableDataCell className="text-center">
                                                <div>{item.AmmountSoughtPKR}</div>
                                            </CTableDataCell>
                                            <CTableDataCell className="text-center">
                                                <div>{item.SalarayDisbursementDay}</div>
                                            </CTableDataCell>
                                            <CTableDataCell className="text-center">
                                                <div>{item.Status}</div>
                                            </CTableDataCell>
                                            <CTableDataCell>
                                                <div>
                                                    <CButton type="button" class="btn btn-outline-primary" onClick={() => { updateStatus(item.applicationID, "verification", item) }}>View Documents</CButton>
                                                    <CButton type="button" class="btn btn-outline-success" onClick={() => { updateStatus(item.applicationID, "approaved") }}>Accept Application</CButton>
                                                    <CButton type="button" class="btn btn-outline-warning" onClick={() => { updateStatus(item.applicationID, "deny") }}>Deny Application</CButton>
                                                </div>
                                            </CTableDataCell>
                                        </CTableRow>
                                    ))}
                                </CTableBody>
                            </CTable>
                        </CCardBody>
                    </CCard>
                </CCol>
            </CRow>
            <CModal size="xl" visible={visible} onClose={() => setVisible(false)}>
                <CModalHeader>
                    <CModalTitle>User Documents</CModalTitle>
                </CModalHeader>
                <CModalBody>
                    <div>
                        <p>
                            <h1>CNIC Pictures</h1>
                            <embed src={`http://127.0.0.1:8000${singleData?.nicPicFile}`} width="100%" height={'700px'} />
                        </p>
                        <p>
                            <h1>Electric Bill</h1>
                            <embed src={`http://127.0.0.1:8000${singleData?.keBillFile}`} width="100%" height={'700px'} />
                        </p>
                        <p>
                            <h1>Gas Bill</h1>
                            <embed src={`http://127.0.0.1:8000${singleData?.gasBillFile}`} width="100%" height={'700px'} />
                        </p>
                        <p>
                            <h1>Bank Statement</h1>
                            <embed src={`http://127.0.0.1:8000${singleData?.bankStatementFile}`} width="100%" height={'700px'} />
                        </p>

                    </div>
                </CModalBody>
                <CModalFooter>
                    <CButton color="secondary" onClick={() => setVisible(false)}>
                        Close
                    </CButton>
                </CModalFooter>
            </CModal>

        </>
    )
}
export default Docverify