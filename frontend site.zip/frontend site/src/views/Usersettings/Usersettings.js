import React from 'react'

const Usersettings = (props) => {
    return (
        <div>Uffff</div>
        


    );
}

export default Usersettings;