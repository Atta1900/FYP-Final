import React, { useState,useEffect } from 'react';
import axios from 'axios';
import {
    CButton,
    CCard,
    CCardBody,
    CCol,
    CForm,
    CFormInput,
    CFormLabel,
    CRow,
} from '@coreui/react'
import DocsExample from '../pages/appforms/DocsExample';

function RepayUser() {
    const [applicationID, setApplicationID] = useState('');
    const [email, setEmail] = useState('');
    const [amount, setAmount] = useState('');
    const [date, setDate] = useState(Date.now());
    const [myData, setmyData] = useState([]);

    const handleSubmit = async (event) => {
        event.preventDefault();

        // Create a payment intent with the backend API
        const response = await fetch('/create_payment_intent/', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                application_id: applicationID,
                email: email,
                amount: amount,
                date: date
            })
        });
    }
      

        const allData = () => {
            axios({
                method: 'GET',
                url: "http://127.0.0.1:8000/api/ApplicationForm"
            })
                .then((response) => {
                    var data = response.data;
                    var userData=data.filter((e)=>{
                        return e.user_id == localStorage.getItem('userid')
                      })
                    setmyData(userData)
                   
                }, (error) => {
                    console.log(error);
                });
        }
        useEffect(() => {
            allData()
        }, [], myData.length)

        // const responseData = await response.json();


    return (
        <div>
            {myData.map((item, index) => (
                <div>
                    <CRow className='justify-content-center'>
                        <CCol md={5}>
                            <CCard className="mb-6">
                                <CCardBody>
                                    <DocsExample>
                                        <CForm className="row g-3">
                                            <h1> Pay Your Installment </h1>
                                            <h4>With Stripe</h4>
                                            <CCol md={6}>
                                                <CFormLabel htmlFor="applicationID">Application ID : </CFormLabel>
                                                <CFormLabel htmlFor="applicationID">:  {item.applicationID}</CFormLabel>
                                            </CCol>
                                            <CCol>
                                                <CFormLabel htmlFor="email">Email:</CFormLabel>
                                                <CFormLabel htmlFor="applicationID"> : {item.email}</CFormLabel>

                                            </CCol>
                                            <CCol>
                                                <CFormLabel htmlFor="amount">Installment Amount:</CFormLabel>
                                                <CFormLabel htmlFor="applicationID">{item.AmmountSoughtPKR * 1.13 / item.DesiredRepTenure}</CFormLabel>
                                            </CCol>
                                            <CFormLabel htmlFor="date">Date:</CFormLabel>
                                            {/* <CFormInput type="date" id="date" value={date} onChange={event => setDate(event.target.value)} required /> */}
                                            <CButton type="submit">Pay with Stripe</CButton>
                                        </CForm>
                                    </DocsExample>
                                </CCardBody>
                            </CCard>
                        </CCol>
                    </CRow>
                </div>
            ))};
        </div>

    );
}

export default RepayUser;