import axios from 'axios';
import React, { useState, useEffect } from 'react'

const Agreement = (props) => {

    const [myData, setmyData] = useState([]);

    const allData = () => {
        axios({
            method: 'GET',
            url: "http://127.0.0.1:8000/api/ApplicationForm"
        })
            .then((response) => {
                var data = response.data;
                var userData=data.filter((e)=>{
                    return e.user_id == localStorage.getItem('userid')
                  })
          
                setmyData(userData)
                console.log(data)
                console.log(singleUser)

            }, (error) => {
                console.log(error);


            });
    }


    useEffect(() => {
        allData()
    }, [], myData.length)


    return (
        <>
            <div>
            
                      
                            
                            <h1>Loan Agreement With Bank</h1>
                           
                            <embed src={`http://127.0.0.1:8000/media/agreement.pdf`} width="100%" height={'700px'} />
                    
            </div>
        </>
    );
}

export default Agreement;