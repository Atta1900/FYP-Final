import axios from 'axios';
import React, { useState, useEffect } from 'react'
import { Document, Page } from 'react-pdf';

const documents = (props) => {

    const [myData, setmyData] = useState([]);

    const allData = () => {
        axios({
            method: 'GET',
            url: "http://127.0.0.1:8000/api/ApplicationForm"
        })
            .then((response) => {
                var data = response.data;
                var userData=data.filter((e)=>{
                    return e.user_id == localStorage.getItem('userid')
                  })
          
                setmyData(userData)
                console.log(userData)
              

            }, (error) => {
                console.log(error);


            });
    }


    useEffect(() => {
        allData()
    }, [], myData.length)


    return (
        <>
            <div>
                {myData.map((e) => (
                    <div key={e.applicationID}>
                        <p>
                            <h1>CNIC Pictures</h1>
                            <embed src={`http://127.0.0.1:8000${e.nicPicFile}`} width="100%" height={'700px'} />
                        </p>
                        <p>
                            <h1>Electric Bill</h1>
                            <embed src={`http://127.0.0.1:8000${e.keBillFile}`} width="100%" height={'700px'} />
                        </p>
                        <p>
                            <h1>Gas Bill</h1>
                            <embed src={`http://127.0.0.1:8000${e.gasBillFile}`} width="100%" height={'700px'} />
                        </p>
                        <p>
                            <h1>Bank Statement</h1>
                            <embed src={`http://127.0.0.1:8000${e.bankStatementFile}`} width="100%" height={'700px'} />
                        </p>

                    </div>
                ))}
            </div>
        </>
    );
}

export default documents;