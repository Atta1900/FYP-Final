import React, { useState, useEffect } from 'react'
import axios from 'axios'
import {
  CAvatar,
  CButton,
  CButtonGroup,
  CCard,
  CCardBody,
  CCardFooter,
  CCardHeader,
  CCol,
  CProgress,
  CRow,
  CTable,
  CTableBody,
  CTableDataCell,
  CTableHead,
  CTableHeaderCell,
  CTableRow,
  CCardImage, CModal,
  CModalBody,
  CModalHeader,
  CModalTitle,
  CModalFooter,
} from '@coreui/react'

import { DocsExample } from 'src/components'
import ReactImg from 'src/assets/images/4.jpeg'

import { CChartLine } from '@coreui/react-chartjs'
import { getStyle, hexToRgba } from '@coreui/utils'
import CIcon from '@coreui/icons-react'
import {
  cibCcAmex,
  cibCcApplePay,
  cibCcMastercard,
  cibCcPaypal,
  cibCcStripe,
  cibCcVisa,
  cibGoogle,
  cibFacebook,
  cibLinkedin,
  cifBr,
  cifEs,
  cifFr,
  cifIn,
  cifPl,
  cifUs,
  cibTwitter,
  cilCloudDownload,
  cilPeople,
  cilUser,
  cilUserFemale,
} from '@coreui/icons'

import avatar1 from 'src/assets/images/avatars/1.jpg'
import avatar2 from 'src/assets/images/avatars/2.jpg'
import avatar3 from 'src/assets/images/avatars/3.jpg'
import avatar4 from 'src/assets/images/avatars/4.jpg'
import avatar5 from 'src/assets/images/avatars/5.jpg'
import avatar6 from 'src/assets/images/avatars/6.jpg'

import WidgetsBrand from '../widgets/WidgetsBrand'
import WidgetsDropdown from '../widgets/WidgetsDropdown'

const Userdashboard = () => {
  // fetching backend data and re-rending on userdashboard
  const [visible, setVisible] = useState(false)

  const [myData, setmyData] = useState([]);

  const allData = () => {
    axios({
      method: 'GET',
      url: "http://127.0.0.1:8000/api/ApplicationForm"
    })
      .then((response) => {
        var data = response.data;
        var userData=data.filter((e)=>{
          return e.user_id == localStorage.getItem('userid')
        })

        setmyData(userData)
        if (userData[0].Alert == "1") {
          setVisible(true)
        }
        console.log(userData)

      }, (error) => {
        console.log(error);


      });
  }


  useEffect(() => {
    allData()
  }, myData.length)


  const updateStatus = async (id, status, item = null) => {
    var formdata = new FormData();
    formdata.append("alert", status);

    axios({
      method: 'PUT',
      url: `http://localhost:8000/api/UpdateAlert/${id}`,
      data: formdata,

    })
      .then((response) => {
        var data = response.data;
        console.log(data)
        allData();
        setVisible(false)

      }, (error) => {
        console.log(error);

      });
    if (status == "verification") {
      setVisible(true)
      setSingleData(item)

    }
  }

  const random = (min, max) => Math.floor(Math.random() * (max - min + 1) + min)


  return (
    <>
      {myData.map((item, applicationID) => (
        <CRow>
          <CCol xs={12}>
            <CCard className="mb-4">
              <CCardHeader>
                <strong>Hi {item.FirstName}</strong>
              </CCardHeader>
              <CCardBody>
                <div className="d-flex justify-content-around p-3" >
                  <CCard style={{ width: '22rem', height: '25%' }}>
                    <CCardImage orientation="top" src={`http://127.0.0.1:8000${item.profilePicFile}`} />
                  </CCard>
                  <CCard style={{ width: '78rem', height: '100pxs' }}>
                    <CCardBody>
                      <strong>{item.FirstName} {item.MiddleName} {item.LastName}</strong>
                      <hr></hr>
                      <strong>{item.email}</strong>
                      <hr></hr>
                      <p>{item.mobileNumber}</p>
                      <hr></hr>
                      <p>Loan Amount = {item.AmmountSoughtPKR} {item.DesiredRepTenure}</p>

                      <hr></hr>
                      <p>Installment Amount = {item.AmmountSoughtPKR * 1.13 / item.DesiredRepTenure}</p>

                    </CCardBody>
                  </CCard>
                </div>
              </CCardBody>
            </CCard>

          </CCol>
        </CRow>

      ))};
      {myData.map((e) => (
        <div className='justify-center' style={{ width: "700", height: "100px" }}>

          <ul className="yprogress-bar theme-blue">
            <li className="step">
              <span className="number">
                {e.Status == "submited" || e.Status == "verification" || e.Status == "approaved" ? " ✔" : null}

              </span>
              <div className="title">Submitted</div>
            </li>
            <li className="step">
              <span className="number">
                {e.Status == "verification" || e.Status == "approaved" ? " ✔" : null}
              </span>
              <div className="title">Verification</div>
            </li>
            <li className="step">
              <span className="number">
                {e.Status == "approaved" ? "✔" : null}
              </span>
              <div className="title">Approaved</div>
            </li>
            <li className="step current">
              <span className="number">
                {e.Status == "disbursed" ? " ✔" : e.Status == "deny" ? "✖" : null}
              </span>
              <div className="title">Disbursed</div>
            </li>
          </ul>
        </div>
      ))}
      <div className='abtpl'><h2>About Personal Loan:</h2></div>
      <div className='lorem'><p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur?</p></div>
      <WidgetsBrand withCharts />

      <CModal size="xl" visible={visible} onClose={() => setVisible(false)}>
        <CModalHeader>
          <CModalTitle>Message From Admin</CModalTitle>
        </CModalHeader>
        <CModalBody>
          <div>
            <h3>Your Payment Date Has Been Passed. Please Try To Make </h3>
          </div>
        </CModalBody>
        <CModalFooter>
          <CButton color="secondary" onClick={() => updateStatus(myData[0].applicationID, "0")}>
            Close
          </CButton>
        </CModalFooter>
      </CModal>
    </>
  )
};
export default Userdashboard
