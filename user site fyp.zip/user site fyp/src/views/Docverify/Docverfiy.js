import React from "react";

const Docverify = (props) => {
    return(
        <div>Docverify</div>
    );
}

export default Docverify;