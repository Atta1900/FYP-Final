import React from 'react'

const Adminsettings = (props) => {
    return(
        <div>Adminsettings</div>
    );
}

export default Adminsettings;